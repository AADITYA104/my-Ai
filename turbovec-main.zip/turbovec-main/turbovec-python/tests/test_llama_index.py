from __future__ import annotations

import json
import numpy as np
import pytest

pytest.importorskip("llama_index.core")

from llama_index.core.schema import NodeRelationship, RelatedNodeInfo, TextNode
from llama_index.core.vector_stores.types import (
    FilterCondition,
    FilterOperator,
    MetadataFilter,
    MetadataFilters,
    VectorStoreQuery,
)

from turbovec import IdMapIndex
from turbovec.llama_index import TurboQuantVectorStore


def _unit_vec(seed: int, dim: int) -> list[float]:
    rng = np.random.default_rng(seed)
    v = rng.standard_normal(dim).astype(np.float32)
    v /= np.linalg.norm(v) + 1e-9
    return v.tolist()


def _make_node(text: str, seed: int, dim: int = 64, metadata: dict | None = None,
               ref_doc_id: str | None = None) -> TextNode:
    node = TextNode(text=text, metadata=metadata or {}, embedding=_unit_vec(seed, dim))
    if ref_doc_id is not None:
        node.relationships[NodeRelationship.SOURCE] = RelatedNodeInfo(node_id=ref_doc_id)
    return node


def test_from_params_creates_index():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    assert store._index.dim == 64
    assert store._index.bit_width == 4
    assert store.stores_text is True
    assert store.is_embedding_query is True


def test_bit_width_3_round_trip():
    # bit_width contract is {2, 3, 4}, matching the core IdMapIndex.
    store = TurboQuantVectorStore.from_params(bit_width=3)
    nodes = [_make_node(t, seed=i) for i, t in enumerate(["a", "b", "c"])]
    store.add(nodes)
    assert store._index.bit_width == 3
    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=1)
    )
    assert result.ids == [nodes[1].node_id]


# ---- Lazy index construction --------------------------------------------

def test_constructor_no_index_is_lazy():
    # No-arg construction yields a lazy-uncommitted IdMapIndex.
    store = TurboQuantVectorStore()
    assert store._index.dim is None
    # Query before any add returns an empty result.
    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=3)
    )
    assert result.nodes == []
    assert result.similarities == []
    assert result.ids == []


def test_lazy_dim_locked_on_first_add():
    store = TurboQuantVectorStore(bit_width=2)
    store.add([_make_node("x", seed=0)])
    assert store._index.dim == 64
    assert store._index.bit_width == 2


def test_from_params_without_dim_is_lazy():
    store = TurboQuantVectorStore.from_params(bit_width=4)
    assert store._index.dim is None


def test_persist_and_load_lazy_uncommitted_store(tmp_path):
    # A store that's never seen an add must round-trip through persist
    # without committing a dim or losing its bit_width.
    store = TurboQuantVectorStore(bit_width=2)
    persist_path = tmp_path / "lazy_store.json"
    store.persist(str(persist_path))
    loaded = TurboQuantVectorStore.from_persist_path(str(persist_path))
    assert loaded._index.dim is None
    assert loaded._index.bit_width == 2
    loaded.add([_make_node("post-load", seed=0)])
    assert loaded._index.dim == 64


def test_add_and_query_returns_nodes():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(5)]
    ids = store.add(nodes)
    assert len(ids) == 5
    assert set(ids) == {n.node_id for n in nodes}

    query = VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=3)
    result = store.query(query)
    assert len(result.nodes) == 3
    assert len(result.similarities) == 3
    assert len(result.ids) == 3
    assert all(isinstance(n, TextNode) for n in result.nodes)


def test_metadata_and_text_roundtrip():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("hello world", seed=1, metadata={"source": "a", "page": 7}),
        _make_node("goodbye world", seed=2, metadata={"source": "b", "page": 12}),
    ]
    store.add(nodes)

    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=2))
    texts = {n.get_content() for n in result.nodes}
    assert texts == {"hello world", "goodbye world"}
    sources = {n.metadata["source"] for n in result.nodes}
    assert sources == {"a", "b"}


def test_ref_doc_id_preserved_through_query():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = _make_node("child text", seed=3, ref_doc_id="parent-doc-123")
    store.add([node])

    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(3, 64), similarity_top_k=1))
    returned = result.nodes[0]
    assert returned.ref_doc_id == "parent-doc-123"


def test_empty_query_returns_empty():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=5))
    assert result.nodes == []
    assert result.similarities == []
    assert result.ids == []


def test_k_larger_than_ntotal_is_clamped():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("a", seed=1), _make_node("b", seed=2)])
    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=100))
    assert len(result.nodes) == 2


def test_query_without_embedding_raises():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("a", seed=1)])
    with pytest.raises(ValueError, match="query_embedding"):
        store.query(VectorStoreQuery(query_embedding=None, similarity_top_k=1))


def test_mismatched_dim_raises():
    store = TurboQuantVectorStore(index=IdMapIndex(32, 4))
    with pytest.raises(ValueError, match="embedding dim"):
        store.add([_make_node("x", seed=1, dim=64)])


def test_persist_and_from_persist_path_roundtrip(tmp_path):
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("one", seed=1, metadata={"n": 1}),
        _make_node("two", seed=2, metadata={"n": 2}),
        _make_node("three", seed=3, metadata={"n": 3}),
    ]
    store.add(nodes)
    persist_path = tmp_path / "store.json"
    store.persist(str(persist_path))

    loaded = TurboQuantVectorStore.from_persist_path(str(persist_path))
    result = loaded.query(VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=3))
    assert {n.get_content() for n in result.nodes} == {"one", "two", "three"}


def test_from_persist_path_missing_raises_file_not_found(tmp_path):
    # Issue #156: `from_persist_path` loads the `.tvim` via the binding
    # first, so a missing persist path must raise FileNotFoundError like
    # the other integrations (which Python-open() their JSON first do).
    with pytest.raises(FileNotFoundError):
        TurboQuantVectorStore.from_persist_path(str(tmp_path / "missing.json"))


def test_failed_persist_preserves_previous_store(tmp_path):
    # Regression test for #159: a persist that fails mid-serialization
    # (non-JSON-serializable node metadata) must not destroy a previously
    # persisted store at the same path, and must not leave temp files.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("one", seed=1), _make_node("two", seed=2)])
    persist_path = tmp_path / "store.json"
    store.persist(str(persist_path))
    before = {p.name: p.read_bytes() for p in tmp_path.iterdir()}

    # Older llama-index-core (roughly < 0.12.40) json-serializes node
    # content eagerly inside node_to_metadata_dict — which our add() calls
    # — so the mid-persist failure this test provokes is unreachable
    # there: add() itself raises and the previously persisted store is
    # trivially untouched. Probe the upstream helper directly (same
    # arguments add() uses) so the gate can never swallow a TypeError
    # raised by turbovec's own code below.
    from llama_index.core.vector_stores.utils import node_to_metadata_dict

    probe = _make_node("probe", seed=99, metadata={"bad": {1, 2, 3}})
    try:
        node_to_metadata_dict(probe, remove_text=False, flat_metadata=False)
    except TypeError:
        pytest.skip(
            "this llama-index-core version serializes node content "
            "eagerly at add() time; the persist-time failure cannot be "
            "provoked"
        )

    store.add([_make_node("bad", seed=3, metadata={"bad": {1, 2, 3}})])

    # The store keeps the JSON-coerced metadata rather than the raw
    # mapping (#497), so a set in node metadata is a list by the time it
    # is stored and persist() no longer trips on it. Where that is true
    # the mid-persist failure is unreachable from metadata at all — the
    # same situation the upstream probe above skips for, one layer down.
    try:
        json.dumps(store._nodes)
    except TypeError:
        pass
    else:
        pytest.skip(
            "stored payloads are JSON-coerced at add() time, so a "
            "persist-time TypeError cannot be provoked through metadata"
        )

    with pytest.raises(TypeError):
        store.persist(str(persist_path))

    # Exact directory equality: both files byte-identical, no strays.
    after = {p.name: p.read_bytes() for p in tmp_path.iterdir()}
    assert after == before
    assert not list(tmp_path.glob("*.tmp*"))
    loaded = TurboQuantVectorStore.from_persist_path(str(persist_path))
    assert len(loaded._node_id_to_u64) == 2


def test_from_persist_dir_loads_default_namespace(tmp_path):
    # StorageContext-style: a directory containing a namespaced filename.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(3)]
    store.add(nodes)
    # Mimic StorageContext.persist's filename layout.
    persist_path = tmp_path / "default__vector_store.json"
    store.persist(str(persist_path))

    loaded = TurboQuantVectorStore.from_persist_dir(str(tmp_path))
    result = loaded.query(
        VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=3)
    )
    assert len(result.nodes) == 3


def test_from_persist_dir_with_custom_namespace(tmp_path):
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("ns-doc", seed=0)])
    persist_path = tmp_path / "custom-ns__vector_store.json"
    store.persist(str(persist_path))

    loaded = TurboQuantVectorStore.from_persist_dir(
        str(tmp_path), namespace="custom-ns"
    )
    assert len(loaded._nodes) == 1


@pytest.mark.parametrize(
    "bad_namespace", ["../x", "a/b", "a\\b", "..", "", ".", "C:foo", "a:b"]
)
def test_from_persist_dir_rejects_traversal_namespace(tmp_path, bad_namespace):
    # Issue #152: a namespace containing a path separator or `..` (or an
    # empty/`.` namespace) would escape persist_dir when composed into the
    # side-car filename. We reject it loudly rather than silently basenaming.
    # Issue #200 extended the guard to ':' — a Windows drive-relative name
    # (`C:foo`) escapes persist_dir without any separator.
    with pytest.raises(ValueError, match="namespace"):
        TurboQuantVectorStore.from_persist_dir(
            str(tmp_path), namespace=bad_namespace
        )


def test_from_persist_dir_traversal_does_not_read_outside(tmp_path):
    # Concretely: a store persisted OUTSIDE the intended persist_dir must not
    # be reachable via a traversal namespace.
    inner = tmp_path / "inner"
    inner.mkdir()
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("secret", seed=0)])
    # Persist a sibling of `inner`, matching the namespace filename shape.
    store.persist(str(tmp_path / "OUTSIDE__vector_store.json"))
    with pytest.raises(ValueError, match="namespace"):
        TurboQuantVectorStore.from_persist_dir(
            str(inner), namespace="../OUTSIDE"
        )


def test_from_persist_dir_legit_namespace_with_dot_roundtrips(tmp_path):
    # A dotted namespace (e.g. a version tag) is accepted, not rejected —
    # only `..`, path separators, and ':' are. This pins single-store
    # behavior; sibling dotted namespaces coexisting is pinned separately
    # below (issue #200).
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("versioned", seed=0)])
    store.persist(str(tmp_path / "v1.2__vector_store.json"))
    loaded = TurboQuantVectorStore.from_persist_dir(
        str(tmp_path), namespace="v1.2"
    )
    assert len(loaded._nodes) == 1


def test_dotted_namespaces_coexist_in_shared_persist_dir(tmp_path):
    # Issue #200 collision repro: v1.2 and v1.3 share a persist_dir. The
    # old with_suffix-based stem handling truncated both to `v1.tvim` /
    # `v1.nodes.json`, so the second persist silently overwrote the first
    # and from_persist_dir("v1.2") returned v1.3's data. Each namespace
    # must map to its own file pair and round-trip its own data.
    store_a = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node_a = _make_node("data for v1.2", seed=1)
    store_a.add([node_a])
    store_a.persist(str(tmp_path / "v1.2__vector_store.json"))

    store_b = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node_b = _make_node("data for v1.3", seed=2)
    store_b.add([node_b])
    store_b.persist(str(tmp_path / "v1.3__vector_store.json"))

    # Distinct, unmangled file pairs on disk.
    assert (tmp_path / "v1.2__vector_store.tvim").exists()
    assert (tmp_path / "v1.2__vector_store.nodes.json").exists()
    assert (tmp_path / "v1.3__vector_store.tvim").exists()
    assert (tmp_path / "v1.3__vector_store.nodes.json").exists()
    assert not (tmp_path / "v1.tvim").exists()

    loaded_a = TurboQuantVectorStore.from_persist_dir(
        str(tmp_path), namespace="v1.2"
    )
    loaded_b = TurboQuantVectorStore.from_persist_dir(
        str(tmp_path), namespace="v1.3"
    )
    assert [n.get_content() for n in loaded_a.get_nodes()] == ["data for v1.2"]
    assert [n.get_content() for n in loaded_b.get_nodes()] == ["data for v1.3"]
    assert loaded_a.get_nodes()[0].node_id == node_a.node_id
    assert loaded_b.get_nodes()[0].node_id == node_b.node_id


def test_from_persist_dir_loads_legacy_mangled_dotted_store(tmp_path):
    # A store persisted by a pre-#200 release under a dotted namespace
    # sits on disk under the MANGLED names (`v1.tvim` / `v1.nodes.json`
    # for namespace v1.2 — with_suffix stripped from the stem's last
    # dot). The load path must fall back to those names when the correct
    # ones are absent. Safe by construction: the mangling made colliding
    # namespaces overwrite each other, so at most one store exists per
    # mangled prefix.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = _make_node("legacy data", seed=3)
    store.add([node])
    store.persist(str(tmp_path / "v1.2__vector_store.json"))
    # Rename to the exact byte-paths the old code produced (verified
    # against main's _split_persist_base + with_suffix pipeline).
    (tmp_path / "v1.2__vector_store.tvim").rename(tmp_path / "v1.tvim")
    (tmp_path / "v1.2__vector_store.nodes.json").rename(tmp_path / "v1.nodes.json")

    loaded = TurboQuantVectorStore.from_persist_dir(
        str(tmp_path), namespace="v1.2"
    )
    assert [n.get_content() for n in loaded.get_nodes()] == ["legacy data"]
    assert loaded.get_nodes()[0].node_id == node.node_id

    # Re-persisting writes the correct (unmangled) filenames.
    loaded.persist(str(tmp_path / "v1.2__vector_store.json"))
    assert (tmp_path / "v1.2__vector_store.tvim").exists()
    assert (tmp_path / "v1.2__vector_store.nodes.json").exists()


def test_non_dotted_namespace_filenames_unchanged(tmp_path):
    # No migration for non-dotted namespaces: the #200 stem fix must
    # produce byte-identical file paths to the previous release
    # (`{namespace}__vector_store.tvim` / `.nodes.json`), so existing
    # stores keep loading with no fallback involved.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("plain", seed=4)])
    store.persist(str(tmp_path / "default__vector_store.json"))
    assert sorted(p.name for p in tmp_path.iterdir()) == [
        "default__vector_store.nodes.json",
        "default__vector_store.tvim",
    ]
    loaded = TurboQuantVectorStore.from_persist_dir(str(tmp_path))
    assert [n.get_content() for n in loaded.get_nodes()] == ["plain"]


def test_add_accepts_generator_input():
    # A generator (one-shot iterable) of N nodes adds N nodes. `add` used
    # to iterate its input twice — the second pass saw an exhausted
    # iterator and crashed with a misleading "expected 2D embedding batch,
    # got 1D". async_add already materialized with list(). (#157)
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    ids = store.add(_make_node(f"gen doc {i}", seed=i) for i in range(5))
    assert len(ids) == 5
    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=5)
    )
    assert len(result.nodes) == 5


def test_delete_by_ref_doc_id_removes_every_matching_node():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a1", seed=1, ref_doc_id="parent-1"),
        _make_node("a2", seed=2, ref_doc_id="parent-1"),
        _make_node("b1", seed=3, ref_doc_id="parent-2"),
    ]
    store.add(nodes)

    store.delete("parent-1")
    # Only the parent-2 node survives.
    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(3, 64), similarity_top_k=5))
    assert {n.get_content() for n in result.nodes} == {"b1"}
    assert len(store._index) == 1


def test_delete_by_missing_ref_doc_id_is_noop():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("a", seed=1, ref_doc_id="parent-1")])
    store.delete("does-not-exist")
    assert len(store._index) == 1


def test_delete_nodes_by_node_id():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a", seed=1),
        _make_node("b", seed=2),
        _make_node("c", seed=3),
    ]
    ids = store.add(nodes)
    store.delete_nodes([ids[0], ids[2]])
    assert len(store._index) == 1
    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(2, 64), similarity_top_k=3))
    assert {n.get_content() for n in result.nodes} == {"b"}


def test_add_upsert_replaces_same_node_id():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    # Build two nodes with the same node_id but different content/embeddings.
    first = TextNode(text="v1", embedding=_unit_vec(1, 64))
    second = TextNode(text="v2", id_=first.node_id, embedding=_unit_vec(2, 64))
    store.add([first])
    store.add([second])
    assert len(store._index) == 1
    result = store.query(VectorStoreQuery(query_embedding=_unit_vec(2, 64), similarity_top_k=1))
    assert result.nodes[0].get_content() == "v2"


def test_add_upsert_dim_mismatch_preserves_existing_node():
    # An upsert whose new embedding fails validation must not destroy the
    # existing node: the delete is deferred until the add succeeds.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    first = TextNode(text="v1", embedding=_unit_vec(1, 64))
    bad = TextNode(text="v2", id_=first.node_id, embedding=_unit_vec(2, 32))
    store.add([first])
    with pytest.raises(ValueError):
        store.add([bad])  # dim 32 != index dim 64

    assert len(store._index) == 1
    assert first.node_id in store._node_id_to_u64
    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=1)
    )
    assert result.nodes[0].get_content() == "v1"


# ------------------- Filtered query -------------------

def _store_with_tiered_nodes() -> TurboQuantVectorStore:
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"doc {i}", seed=i, metadata={"tier": tier, "idx": i})
        for i, tier in enumerate(["free", "pro", "free", "pro", "enterprise"])
    ]
    store.add(nodes)
    return store


def test_query_with_eq_filter():
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    result = store.query(q)
    assert len(result.nodes) == 2
    assert all(n.metadata["tier"] == "pro" for n in result.nodes)


def test_query_with_in_filter():
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[
            MetadataFilter(
                key="tier", value=["pro", "enterprise"], operator=FilterOperator.IN
            )
        ]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    result = store.query(q)
    assert len(result.nodes) == 3
    assert all(n.metadata["tier"] in {"pro", "enterprise"} for n in result.nodes)


def test_query_with_and_filter():
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[
            MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ),
            MetadataFilter(key="idx", value=2, operator=FilterOperator.GT),
        ],
        condition=FilterCondition.AND,
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    result = store.query(q)
    # tier=="pro" matches idx 1, 3; combined with idx > 2 leaves only idx=3.
    assert len(result.nodes) == 1
    assert result.nodes[0].metadata["idx"] == 3


def test_query_with_or_filter():
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[
            MetadataFilter(key="tier", value="enterprise", operator=FilterOperator.EQ),
            MetadataFilter(key="idx", value=0, operator=FilterOperator.EQ),
        ],
        condition=FilterCondition.OR,
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    result = store.query(q)
    # enterprise = idx 4, OR idx==0 → 2 nodes total.
    assert len(result.nodes) == 2
    idxs = {n.metadata["idx"] for n in result.nodes}
    assert idxs == {0, 4}


def test_query_filter_no_matches_returns_empty():
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="nonexistent", operator=FilterOperator.EQ)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=5, filters=filters
    )
    result = store.query(q)
    assert result.nodes == []
    assert result.similarities == []
    assert result.ids == []


def test_query_filter_selective_returns_top_k_from_matches():
    # 50 nodes, filter selects 3 — we must return all 3 even when top_k=3
    # and the matching nodes wouldn't be in the unfiltered top-3.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"doc {i}", seed=i, metadata={"tag": "needle" if i in (7, 23, 41) else "hay"})
        for i in range(50)
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tag", value="needle", operator=FilterOperator.EQ)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=3, filters=filters
    )
    result = store.query(q)
    assert len(result.nodes) == 3
    assert all(n.metadata["tag"] == "needle" for n in result.nodes)


def test_query_with_node_ids_filter():
    # `node_ids` restricts to specific node_ids — matches SimpleVectorStore's
    # canonical behaviour.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(5)]
    store.add(nodes)
    keep = [nodes[1].node_id, nodes[3].node_id]
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=5, node_ids=keep
    )
    result = store.query(q)
    assert len(result.nodes) == 2
    assert {n.node_id for n in result.nodes} == set(keep)


def test_query_empty_node_ids_means_no_restriction():
    # Maintainer ruling on issue #130: `query(node_ids=[])` restricts
    # NOTHING — it returns the unrestricted top-k. This pins the
    # framework calling convention: VectorStoreIndex.as_retriever passes
    # node_ids=list(index_struct.nodes_dict.values()), and for a
    # stores_text=True store nodes_dict stays empty — so every retriever
    # query arrives with node_ids=[] meaning "unrestricted". Treating []
    # as match-nothing would make every VectorStoreIndex retrieval over
    # this store return zero results.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(4)]
    store.add(nodes)

    unrestricted = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=4)
    )
    with_empty = store.query(
        VectorStoreQuery(
            query_embedding=_unit_vec(0, 64), similarity_top_k=4, node_ids=[]
        )
    )
    assert len(with_empty.nodes) == 4
    assert with_empty.ids == unrestricted.ids
    assert with_empty.similarities == unrestricted.similarities

    # doc_ids=[] follows the same convention (as in SimpleVectorStore).
    with_empty_docs = store.query(
        VectorStoreQuery(
            query_embedding=_unit_vec(0, 64), similarity_top_k=4, doc_ids=[]
        )
    )
    assert with_empty_docs.ids == unrestricted.ids

    # Contrast: get_nodes / delete_nodes are direct node-selection APIs —
    # an explicit empty list there is an empty selection.
    assert store.get_nodes(node_ids=[]) == []
    store.delete_nodes(node_ids=[])  # no-op
    assert len(store.get_nodes()) == 4


def test_query_with_doc_ids_filter_matches_ref_doc_id_only():
    # `doc_ids` filters by `ref_doc_id` (source document), not node_id.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"chunk {i}", seed=i, ref_doc_id=f"src-{i // 2}")
        for i in range(6)
    ]
    store.add(nodes)
    # Two source docs: src-0 (chunks 0, 1) and src-1 (chunks 2, 3).
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64),
        similarity_top_k=10,
        doc_ids=["src-0", "src-1"],
    )
    result = store.query(q)
    assert len(result.nodes) == 4
    # A bare node_id passed via doc_ids does NOT match; that's what node_ids
    # is for.
    q2 = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64),
        similarity_top_k=10,
        doc_ids=[nodes[0].node_id],
    )
    assert store.query(q2).nodes == []


def test_query_with_node_ids_and_filters_intersect():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"doc {i}", seed=i, metadata={"tier": "pro" if i % 2 else "free"})
        for i in range(6)
    ]
    store.add(nodes)
    keep = [nodes[i].node_id for i in (0, 1, 2, 3)]  # narrow to first four
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64),
        similarity_top_k=10,
        node_ids=keep,
        filters=filters,
    )
    result = store.query(q)
    # tier=="pro" → odd indices (1, 3, 5). Intersect with {0,1,2,3} → {1,3}.
    assert {n.node_id for n in result.nodes} == {nodes[1].node_id, nodes[3].node_id}


def test_query_ne_filter_keeps_nodes_missing_the_key():
    # A node MISSING the filtered key satisfies the NEGATIVE operators —
    # "tier is not pro" is vacuously true of a node with no tier — while
    # the positive operators still decline. Matches llama-index-core
    # >= 0.14; 0.12.x excluded these. (#302)
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("with", seed=0, metadata={"tier": "free"}),
        _make_node("without", seed=1, metadata={}),  # no `tier` key
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="pro", operator=FilterOperator.NE)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    result = store.query(q)
    assert {n.get_content() for n in result.nodes} == {"with", "without"}

    # The positive counterpart still excludes the key-less node.
    eq = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="free", operator=FilterOperator.EQ)]
    )
    q_eq = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=eq
    )
    assert {n.get_content() for n in store.query(q_eq).nodes} == {"with"}


def test_single_filter_missing_key_semantics():
    # Table-driven parity check against the canonical in-tree evaluator,
    # `SimpleVectorStore`'s `_build_metadata_filter_fn`: for a node missing
    # the filtered key, EVERY operator returns False. (#302)
    metadata: dict = {"other": 1}  # no "color" key
    # Positive operators decline on a missing key; the negative ones are
    # vacuously satisfied. NOT compared against the live reference:
    # llama-index-core changed this between 0.12.x (all False) and 0.14.x
    # (NE/NIN True), so a parity assertion here fails on one or the other.
    cases = [
        (FilterOperator.EQ, "red", False),
        (FilterOperator.NE, "red", True),
        (FilterOperator.IN, ["red", "blue"], False),
        (FilterOperator.NIN, ["red", "blue"], True),
    ]
    for op, value, expected in cases:
        filters = MetadataFilters(
            filters=[MetadataFilter(key="color", value=value, operator=op)]
        )
        actual = TurboQuantVectorStore._filters_match(metadata, filters)
        assert actual == expected, f"{op.name} on missing key: got {actual}"
    # A present key still compares normally.
    present = {"color": "blue"}
    ne = MetadataFilters(
        filters=[MetadataFilter(key="color", value="red", operator=FilterOperator.NE)]
    )
    assert TurboQuantVectorStore._filters_match(present, ne) is True
    assert TurboQuantVectorStore._filters_match({"color": "red"}, ne) is False


def test_query_text_match_is_case_sensitive():
    # `FilterOperator` defines TEXT_MATCH and TEXT_MATCH_INSENSITIVE as
    # separate operators, so TEXT_MATCH must NOT fold case — otherwise
    # there is no way to ask for a case-sensitive match. (#302)
    #
    # Deliberately not compared against the live reference:
    # llama-index-core changed this between 0.12.x (lowercased both
    # sides) and 0.14.x (case-sensitive), so a parity assertion here
    # passes on one version and fails on the other.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a", seed=0, metadata={"title": "The Lord of the Rings"}),
        _make_node("b", seed=1, metadata={"title": "Lord of Light"}),
        _make_node("c", seed=2, metadata={"title": "The Hobbit"}),
    ]
    store.add(nodes)

    def titles_for(probe: str) -> set[str]:
        filters = MetadataFilters(
            filters=[
                MetadataFilter(
                    key="title", value=probe, operator=FilterOperator.TEXT_MATCH
                )
            ]
        )
        q = VectorStoreQuery(
            query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
        )
        return {n.metadata["title"] for n in store.query(q).nodes}

    assert titles_for("Lord") == {"The Lord of the Rings", "Lord of Light"}
    assert titles_for("LORD") == set()
    assert titles_for("lord") == set()


@pytest.mark.skipif(
    not hasattr(FilterOperator, "TEXT_MATCH_INSENSITIVE"),
    reason="FilterOperator.TEXT_MATCH_INSENSITIVE requires llama-index-core >= 0.12.6",
)
def test_query_text_match_insensitive_folds_case():
    # TEXT_MATCH_INSENSITIVE is the explicit opt-in for case-folding,
    # matching `utils.py:145-151`.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a", seed=0, metadata={"title": "The Lord of the Rings"}),
        _make_node("b", seed=1, metadata={"title": "Lord of Light"}),
        _make_node("c", seed=2, metadata={"title": "The Hobbit"}),
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[
            MetadataFilter(
                key="title",
                value="LORD",
                operator=FilterOperator.TEXT_MATCH_INSENSITIVE,
            )
        ]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    titles = {n.metadata["title"] for n in store.query(q).nodes}
    assert titles == {"The Lord of the Rings", "Lord of Light"}


def test_query_text_match_raises_type_error_on_non_string_operands():
    # Reference rejects non-string operands with a TypeError so the caller
    # can't silently fall through to string-coerced behaviour.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("a", seed=0, metadata={"page": 7})])
    filters = MetadataFilters(
        filters=[
            MetadataFilter(key="page", value="7", operator=FilterOperator.TEXT_MATCH)
        ]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=1, filters=filters
    )
    with pytest.raises(TypeError, match="TEXT_MATCH"):
        store.query(q)


def test_query_all_operator_matches_set_subset():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a", seed=0, metadata={"tags": ["python", "rust", "go"]}),
        _make_node("b", seed=1, metadata={"tags": ["python", "rust"]}),
        _make_node("c", seed=2, metadata={"tags": ["python"]}),
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[
            MetadataFilter(
                key="tags", value=["python", "rust"], operator=FilterOperator.ALL
            )
        ]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    contents = {n.get_content() for n in store.query(q).nodes}
    assert contents == {"a", "b"}


def test_query_any_operator_matches_set_intersection():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a", seed=0, metadata={"tags": ["python"]}),
        _make_node("b", seed=1, metadata={"tags": ["rust"]}),
        _make_node("c", seed=2, metadata={"tags": ["go"]}),
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[
            MetadataFilter(
                key="tags", value=["python", "rust"], operator=FilterOperator.ANY
            )
        ]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    contents = {n.get_content() for n in store.query(q).nodes}
    assert contents == {"a", "b"}


def test_all_any_filters_work_without_newer_enum_members(monkeypatch):
    # Regression (issue #160): the operator dispatch used to reference
    # FilterOperator.TEXT_MATCH_INSENSITIVE (added in llama-index-core
    # 0.12.6) unconditionally, BEFORE the ALL/ANY branches — on older
    # releases every ALL/ANY (and unknown-operator) query died with
    # AttributeError instead of matching. Same for FilterCondition.NOT in
    # the condition dispatch. Simulate an old llama-index-core by swapping
    # in stub enums that lack the newer members (str-enums compare by
    # value, so real filter objects still match the stub's members) and
    # check the dispatch never touches the missing attributes.
    import enum

    import turbovec.llama_index as tli

    class OldFilterOperator(str, enum.Enum):  # llama-index-core 0.11.0 surface
        EQ = "=="
        GT = ">"
        LT = "<"
        NE = "!="
        GTE = ">="
        LTE = "<="
        IN = "in"
        NIN = "nin"
        ANY = "any"
        ALL = "all"
        TEXT_MATCH = "text_match"
        CONTAINS = "contains"
        IS_EMPTY = "is_empty"

    class OldFilterCondition(str, enum.Enum):  # no NOT before 0.12.6
        AND = "and"
        OR = "or"

    monkeypatch.setattr(tli, "FilterOperator", OldFilterOperator)
    monkeypatch.setattr(tli, "FilterCondition", OldFilterCondition)
    monkeypatch.setattr(
        tli,
        "_TEXT_MATCH_INSENSITIVE",
        getattr(OldFilterOperator, "TEXT_MATCH_INSENSITIVE", None),
    )
    monkeypatch.setattr(
        tli, "_CONDITION_NOT", getattr(OldFilterCondition, "NOT", None)
    )

    metadata = {"tags": ["python", "rust", "go"]}
    all_match = MetadataFilters(
        filters=[
            MetadataFilter(
                key="tags", value=["python", "rust"], operator=FilterOperator.ALL
            )
        ]
    )
    any_match = MetadataFilters(
        filters=[
            MetadataFilter(
                key="tags", value=["haskell", "go"], operator=FilterOperator.ANY
            )
        ]
    )
    any_miss = MetadataFilters(
        filters=[
            MetadataFilter(
                key="tags", value=["haskell"], operator=FilterOperator.ANY
            )
        ]
    )
    assert TurboQuantVectorStore._filters_match(metadata, all_match) is True
    assert TurboQuantVectorStore._filters_match(metadata, any_match) is True
    assert TurboQuantVectorStore._filters_match(metadata, any_miss) is False

    # Condition dispatch: on the old enum surface a NOT condition (built
    # with the installed real enum, so only constructible where the
    # member exists — i.e. llama-index-core >= 0.12.6, which is what CI
    # runs) must fall through to the explicit NotImplementedError — the
    # unfixed code instead dies with AttributeError touching the missing
    # FilterCondition.NOT on the stub.
    if hasattr(FilterCondition, "NOT"):
        not_filters = MetadataFilters(
            filters=[
                MetadataFilter(
                    key="tags", value=["python"], operator=FilterOperator.IN
                )
            ],
            condition=FilterCondition.NOT,
        )
        with pytest.raises(NotImplementedError):
            TurboQuantVectorStore._filters_match(metadata, not_filters)


def test_query_is_empty_treats_missing_key_as_match():
    # Reference (`utils.py:168-173`): IS_EMPTY matches when the key is
    # absent OR the value is empty string / empty list. Trickiest branch
    # because it's the only operator where a missing key is a hit.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([
        _make_node("a", seed=0, metadata={"note": "x"}),
        _make_node("b", seed=1, metadata={}),
        _make_node("c", seed=2, metadata={"note": ""}),
        _make_node("d", seed=3, metadata={"note": []}),
    ])
    filters = MetadataFilters(
        filters=[MetadataFilter(key="note", value=None, operator=FilterOperator.IS_EMPTY)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    contents = {n.get_content() for n in store.query(q).nodes}
    # All three "empty-ish" rows match; the populated one does not.
    assert contents == {"b", "c", "d"}


def test_query_contains_operator_matches_list_membership():
    # CONTAINS — the canonical "scalar value in list-valued metadata"
    # predicate. Distinct from ALL/ANY (which take list-valued targets).
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([
        _make_node("a", seed=0, metadata={"tags": ["python", "rust"]}),
        _make_node("b", seed=1, metadata={"tags": ["go"]}),
        _make_node("c", seed=2, metadata={"tags": ["python"]}),
    ])
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tags", value="python", operator=FilterOperator.CONTAINS)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    contents = {n.get_content() for n in store.query(q).nodes}
    assert contents == {"a", "c"}


def _store_with_scored_nodes() -> TurboQuantVectorStore:
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([
        _make_node(f"doc-{i}", seed=i, metadata={"score": i})
        for i in range(5)
    ])
    return store


def test_query_with_lt_filter():
    filters = MetadataFilters(
        filters=[MetadataFilter(key="score", value=2, operator=FilterOperator.LT)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    scores = {n.metadata["score"] for n in _store_with_scored_nodes().query(q).nodes}
    assert scores == {0, 1}


def test_query_with_lte_filter():
    # Boundary case: LTE must include the threshold value (where LT excludes it).
    filters = MetadataFilters(
        filters=[MetadataFilter(key="score", value=2, operator=FilterOperator.LTE)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    scores = {n.metadata["score"] for n in _store_with_scored_nodes().query(q).nodes}
    assert scores == {0, 1, 2}


def test_query_with_gte_filter():
    # Boundary case: GTE must include the threshold value (where GT excludes it).
    filters = MetadataFilters(
        filters=[MetadataFilter(key="score", value=3, operator=FilterOperator.GTE)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    scores = {n.metadata["score"] for n in _store_with_scored_nodes().query(q).nodes}
    assert scores == {3, 4}


def test_query_with_nin_filter():
    # NIN — values NOT in the supplied list. Distinct branch from IN.
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value=["pro"], operator=FilterOperator.NIN)]
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    tiers = {n.metadata["tier"] for n in store.query(q).nodes}
    assert tiers == {"free", "enterprise"}


def test_query_contradictive_same_key_and_returns_empty():
    # Two EQ filters on the same key with different values, joined by
    # AND, must return zero matches. Confirms AND is genuinely
    # conjunctive over same-key duplicates rather than accidentally
    # last-wins / OR.
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[
            MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ),
            MetadataFilter(key="tier", value="free", operator=FilterOperator.EQ),
        ],
        condition=FilterCondition.AND,
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    assert store.query(q).nodes == []


def test_query_returns_results_sorted_by_similarity():
    # Top-1 of a self-query (query embedding == one of the stored
    # embeddings) must be that exact node. Quantization noise is small
    # enough that the self-match wins, and this is the only guard
    # against a regression that returns hits in insertion order.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc-{i}", seed=i) for i in range(5)]
    ids = store.add(nodes)
    # Query with the embedding of node index 3.
    q = VectorStoreQuery(query_embedding=_unit_vec(3, 64), similarity_top_k=5)
    result = store.query(q)
    assert result.ids[0] == ids[3]
    # Similarities must be monotonically non-increasing (top-k contract).
    sims = result.similarities
    assert all(a >= b for a, b in zip(sims, sims[1:]))


@pytest.mark.skipif(
    not hasattr(FilterCondition, "NOT"),
    reason="FilterCondition.NOT requires llama-index-core >= 0.12.6",
)
def test_query_filter_condition_not_negates_inner_match():
    # Reference (`utils.py:187-189`): NOT matches when NONE of the inner
    # filters match. With a single inner EQ filter, NOT is just negation.
    store = _store_with_tiered_nodes()
    filters = MetadataFilters(
        filters=[
            MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ)
        ],
        condition=FilterCondition.NOT,
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=filters
    )
    tiers = {n.metadata["tier"] for n in store.query(q).nodes}
    assert "pro" not in tiers
    assert tiers == {"free", "enterprise"}


def test_query_nested_filter_groups_are_supported_superset():
    # Deliberate superset of the reference (#165): SimpleVectorStore's
    # build_metadata_filter_fn raises ValueError on nested MetadataFilters
    # groups; turbovec recurses into them. Pin the recursion's semantics:
    # (tier == "pro" OR tier == "free") AND region == "eu".
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node("a", seed=1, metadata={"tier": "pro", "region": "eu"}),
        _make_node("b", seed=2, metadata={"tier": "free", "region": "us"}),
        _make_node("c", seed=3, metadata={"tier": "free", "region": "eu"}),
        _make_node("d", seed=4, metadata={"tier": "enterprise", "region": "eu"}),
    ]
    store.add(nodes)
    inner = MetadataFilters(
        filters=[
            MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ),
            MetadataFilter(key="tier", value="free", operator=FilterOperator.EQ),
        ],
        condition=FilterCondition.OR,
    )
    outer = MetadataFilters(
        filters=[
            inner,
            MetadataFilter(key="region", value="eu", operator=FilterOperator.EQ),
        ],
        condition=FilterCondition.AND,
    )
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64), similarity_top_k=10, filters=outer
    )
    texts = {n.get_content() for n in store.query(q).nodes}
    assert texts == {"a", "c"}


# ------------------- Tier 1: protocol completeness -----------------------

def test_get_raises_with_explanation():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node("a", seed=1)]
    ids = store.add(nodes)
    with pytest.raises(NotImplementedError, match="quantiz"):
        store.get(ids[0])


def test_get_nodes_by_node_ids():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(3)]
    ids = store.add(nodes)
    fetched = store.get_nodes(node_ids=[ids[0], ids[2]])
    assert {n.node_id for n in fetched} == {ids[0], ids[2]}
    # Missing ids are silently skipped, matching SimpleVectorStore-ish convention.
    fetched = store.get_nodes(node_ids=[ids[0], "nonexistent"])
    assert {n.node_id for n in fetched} == {ids[0]}


def test_get_nodes_returns_requested_id_order():
    # Results come back in the order the ids were requested (missing ids
    # silently skipped), matching the LangChain integration's get_by_ids —
    # not in storage/insertion order. (#150)
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(3)]
    ids = store.add(nodes)  # storage order: ids[0], ids[1], ids[2]
    fetched = store.get_nodes(node_ids=[ids[2], "nonexistent", ids[0]])
    assert [n.node_id for n in fetched] == [ids[2], ids[0]]


def test_get_nodes_by_filters():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"doc {i}", seed=i, metadata={"tier": "pro" if i % 2 else "free"})
        for i in range(4)
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ)]
    )
    fetched = store.get_nodes(filters=filters)
    assert len(fetched) == 2
    assert all(n.metadata["tier"] == "pro" for n in fetched)


def test_get_nodes_intersects_node_ids_and_filters():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"doc {i}", seed=i, metadata={"tier": "pro" if i % 2 else "free"})
        for i in range(4)
    ]
    ids = store.add(nodes)
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ)]
    )
    fetched = store.get_nodes(node_ids=[ids[0], ids[1]], filters=filters)
    # tier==pro is odd indices → {ids[1], ids[3]}. Intersect with {ids[0], ids[1]} → {ids[1]}.
    assert [n.node_id for n in fetched] == [ids[1]]


def test_get_nodes_empty_filter_returns_all():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [_make_node(f"doc {i}", seed=i) for i in range(3)]
    store.add(nodes)
    fetched = store.get_nodes()
    assert len(fetched) == 3


def test_clear_resets_store():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=2)
    store.add([_make_node(f"doc {i}", seed=i) for i in range(3)])
    assert len(store._nodes) == 3
    store.clear()
    assert len(store._nodes) == 0
    assert len(store._index) == 0
    # bit_width is preserved across clear; dim resets to lazy.
    assert store._index.bit_width == 2
    assert store._index.dim is None
    # The cleared store is still usable.
    store.add([_make_node("post-clear", seed=0)])
    assert len(store._nodes) == 1


def test_delete_nodes_with_filters():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    nodes = [
        _make_node(f"doc {i}", seed=i, metadata={"tier": "pro" if i % 2 else "free"})
        for i in range(4)
    ]
    store.add(nodes)
    filters = MetadataFilters(
        filters=[MetadataFilter(key="tier", value="pro", operator=FilterOperator.EQ)]
    )
    store.delete_nodes(filters=filters)
    assert len(store._nodes) == 2
    assert all(data["metadata"]["tier"] == "free" for data in store._nodes.values())


def test_delete_nodes_no_args_is_noop():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("a", seed=1)])
    store.delete_nodes()
    assert len(store._nodes) == 1


def test_to_dict_from_dict_roundtrip():
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=2)
    cfg = store.to_dict()
    assert cfg["bit_width"] == 2
    assert cfg["dim"] == 64
    restored = TurboQuantVectorStore.from_dict(cfg)
    assert restored._index.dim == 64
    assert restored._index.bit_width == 2


def test_to_dict_from_dict_lazy_store():
    store = TurboQuantVectorStore(bit_width=2)
    cfg = store.to_dict()
    assert cfg["dim"] is None
    restored = TurboQuantVectorStore.from_dict(cfg)
    assert restored._index.dim is None
    assert restored._index.bit_width == 2


# ------------------- Tier 2: async overrides -----------------------------

def test_async_add_query_delete_clear_get():
    import asyncio

    async def runner():
        store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
        nodes = [_make_node(f"doc {i}", seed=i) for i in range(3)]
        await store.async_add(nodes)
        result = await store.aquery(
            VectorStoreQuery(query_embedding=_unit_vec(0, 64), similarity_top_k=3)
        )
        assert len(result.nodes) == 3
        fetched = await store.aget_nodes(node_ids=[n.node_id for n in nodes[:2]])
        assert len(fetched) == 2
        await store.adelete_nodes(node_ids=[nodes[0].node_id])
        assert len(store._nodes) == 2
        await store.aclear()
        assert len(store._nodes) == 0

    asyncio.run(runner())


def test_async_adelete_by_ref_doc_id():
    import asyncio

    async def runner():
        store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
        store.add([
            _make_node("a", seed=1, ref_doc_id="parent"),
            _make_node("b", seed=2, ref_doc_id="parent"),
            _make_node("c", seed=3, ref_doc_id="other"),
        ])
        await store.adelete("parent")
        assert len(store._nodes) == 1

    asyncio.run(runner())


# ------------------- End-to-end smoke tests: framework wiring -----------

def test_vector_store_index_from_vector_store_retrieve():
    # Smoke test: build a full VectorStoreIndex on top of our store and
    # retrieve through it. This is the canonical way users plug a vector
    # store into a LlamaIndex pipeline (RAG, query engine, etc.), so it
    # exercises the index/retriever glue that calls query() on us from
    # the framework side.
    from llama_index.core import VectorStoreIndex, StorageContext
    from llama_index.core.embeddings import MockEmbedding
    from llama_index.core.schema import TextNode as LITextNode

    embed_model = MockEmbedding(embed_dim=64)
    store = TurboQuantVectorStore.from_params(bit_width=4)

    # Build nodes with embeddings (MockEmbedding is deterministic).
    nodes = []
    for i, text in enumerate(["alpha doc", "beta doc", "gamma doc"]):
        node = LITextNode(text=text, id_=f"n-{i}")
        node.embedding = embed_model.get_text_embedding(text)
        nodes.append(node)
    store.add(nodes)

    storage_context = StorageContext.from_defaults(vector_store=store)
    index = VectorStoreIndex(nodes=[], storage_context=storage_context, embed_model=embed_model)
    retriever = index.as_retriever(similarity_top_k=2)
    results = retriever.retrieve("alpha")
    assert len(results) == 2
    # Returned NodeWithScore objects wrap our TextNodes.
    assert all(r.score is not None for r in results)
    contents = {r.node.get_content() for r in results}
    assert contents.issubset({"alpha doc", "beta doc", "gamma doc"})


def test_storage_context_persist_and_load_roundtrip(tmp_path):
    # Smoke test: persist via StorageContext, reload via StorageContext.
    # This is the path real LlamaIndex users follow, and it depends on
    # our from_persist_dir + persist signature matching the framework's
    # expectations.
    from llama_index.core import VectorStoreIndex, StorageContext
    from llama_index.core.embeddings import MockEmbedding
    from llama_index.core.schema import TextNode as LITextNode

    embed_model = MockEmbedding(embed_dim=64)
    persist_dir = tmp_path / "storage"

    # Build, persist.
    store = TurboQuantVectorStore.from_params(bit_width=4)
    nodes = []
    for i, text in enumerate(["one", "two", "three"]):
        node = LITextNode(text=text, id_=f"n-{i}")
        node.embedding = embed_model.get_text_embedding(text)
        nodes.append(node)
    store.add(nodes)

    storage_context = StorageContext.from_defaults(vector_store=store)
    storage_context.persist(persist_dir=str(persist_dir))

    # Reload via the from_persist_dir path.
    reloaded_store = TurboQuantVectorStore.from_persist_dir(str(persist_dir))
    assert len(reloaded_store._nodes) == 3
    # Original query still works after reload.
    storage_context2 = StorageContext.from_defaults(
        vector_store=reloaded_store, persist_dir=str(persist_dir),
    )
    index = VectorStoreIndex(
        nodes=[], storage_context=storage_context2, embed_model=embed_model,
    )
    retriever = index.as_retriever(similarity_top_k=2)
    results = retriever.retrieve("one")
    assert len(results) == 2


# ---- Full-node fidelity round-trip (covers the langchain-class bug
# pattern at the structural level: every field SimpleVectorStore would
# preserve through write -> query / get_nodes / persist+load must come
# back populated, not a bare {id, text, metadata} TextNode shell). ----

def _make_rich_node(
    text: str,
    seed: int,
    *,
    node_id: str | None = None,
    metadata: dict | None = None,
    excluded_embed_metadata_keys: list[str] | None = None,
    excluded_llm_metadata_keys: list[str] | None = None,
    relationships: dict | None = None,
    start_char_idx: int | None = None,
    end_char_idx: int | None = None,
    metadata_template: str | None = None,
    metadata_separator: str | None = None,
    text_template: str | None = None,
    mimetype: str | None = None,
) -> TextNode:
    """A TextNode with every framework field set to a non-default value so
    we can assert each one survives the write -> retrieve round-trip."""
    kwargs: dict = {
        "text": text,
        "metadata": metadata or {},
        "embedding": _unit_vec(seed, 64),
        "excluded_embed_metadata_keys": excluded_embed_metadata_keys or [],
        "excluded_llm_metadata_keys": excluded_llm_metadata_keys or [],
        "relationships": relationships or {},
    }
    if node_id is not None:
        kwargs["id_"] = node_id
    if start_char_idx is not None:
        kwargs["start_char_idx"] = start_char_idx
    if end_char_idx is not None:
        kwargs["end_char_idx"] = end_char_idx
    if metadata_template is not None:
        kwargs["metadata_template"] = metadata_template
    if metadata_separator is not None:
        kwargs["metadata_separator"] = metadata_separator
    if text_template is not None:
        kwargs["text_template"] = text_template
    if mimetype is not None:
        kwargs["mimetype"] = mimetype
    return TextNode(**kwargs)


def test_query_returns_node_with_full_field_fidelity():
    # Every field SimpleVectorStore preserves through query must survive
    # turbovec's write -> query round-trip. The previous narrow side-car
    # schema lost relationships (PREVIOUS/NEXT/PARENT/CHILD),
    # excluded_*_metadata_keys, template fields, char_idx, and mimetype.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = _make_rich_node(
        "chunk text",
        seed=1,
        node_id="node-rich-1",
        metadata={"page": 7, "section": "intro"},
        excluded_embed_metadata_keys=["section"],
        excluded_llm_metadata_keys=["page"],
        relationships={
            NodeRelationship.SOURCE: RelatedNodeInfo(node_id="doc-1"),
            NodeRelationship.PREVIOUS: RelatedNodeInfo(node_id="node-prev"),
            NodeRelationship.NEXT: RelatedNodeInfo(node_id="node-next"),
            NodeRelationship.PARENT: RelatedNodeInfo(node_id="node-parent"),
        },
        start_char_idx=100,
        end_char_idx=200,
        metadata_template="<<{key}::{value}>>",
        metadata_separator="|SEP|",
        text_template="META:{metadata_str}\nBODY:{content}",
        mimetype="text/markdown",
    )
    store.add([node])

    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=1)
    )
    [returned] = result.nodes

    assert returned.node_id == "node-rich-1"
    assert returned.get_content() == "chunk text"
    assert returned.metadata == {"page": 7, "section": "intro"}
    assert returned.excluded_embed_metadata_keys == ["section"]
    assert returned.excluded_llm_metadata_keys == ["page"]
    assert returned.start_char_idx == 100
    assert returned.end_char_idx == 200
    assert returned.metadata_template == "<<{key}::{value}>>"
    assert returned.metadata_separator == "|SEP|"
    assert returned.text_template == "META:{metadata_str}\nBODY:{content}"
    assert returned.mimetype == "text/markdown"
    # All four relationships should be present, not just SOURCE.
    assert returned.relationships[NodeRelationship.SOURCE].node_id == "doc-1"
    assert returned.relationships[NodeRelationship.PREVIOUS].node_id == "node-prev"
    assert returned.relationships[NodeRelationship.NEXT].node_id == "node-next"
    assert returned.relationships[NodeRelationship.PARENT].node_id == "node-parent"


def test_get_nodes_returns_full_field_fidelity():
    # Same fidelity contract for get_nodes (not just query).
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = _make_rich_node(
        "chunk",
        seed=2,
        node_id="g-1",
        metadata={"k": "v"},
        excluded_embed_metadata_keys=["k"],
        relationships={
            NodeRelationship.SOURCE: RelatedNodeInfo(node_id="doc"),
            NodeRelationship.NEXT: RelatedNodeInfo(node_id="g-2"),
        },
        start_char_idx=0,
        end_char_idx=5,
        mimetype="application/json",
    )
    store.add([node])

    [fetched] = store.get_nodes(node_ids=["g-1"])
    assert fetched.relationships[NodeRelationship.NEXT].node_id == "g-2"
    assert fetched.excluded_embed_metadata_keys == ["k"]
    assert fetched.mimetype == "application/json"
    assert fetched.start_char_idx == 0
    assert fetched.end_char_idx == 5


def test_persist_round_trip_preserves_full_node_fidelity(tmp_path):
    # Save + load should not be lossier than query — the on-disk schema
    # must carry the full _node_content blob (v2+).
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = _make_rich_node(
        "persisted chunk",
        seed=3,
        node_id="p-1",
        metadata={"k": "v"},
        relationships={
            NodeRelationship.SOURCE: RelatedNodeInfo(node_id="doc"),
            NodeRelationship.PREVIOUS: RelatedNodeInfo(node_id="p-0"),
        },
        excluded_llm_metadata_keys=["k"],
        text_template="T:{content}",
    )
    store.add([node])
    persist_path = tmp_path / "store.json"
    store.persist(str(persist_path))

    loaded = TurboQuantVectorStore.from_persist_path(str(persist_path))
    [restored] = loaded.get_nodes(node_ids=["p-1"])
    assert restored.relationships[NodeRelationship.PREVIOUS].node_id == "p-0"
    assert restored.excluded_llm_metadata_keys == ["k"]
    assert restored.text_template == "T:{content}"


def test_persist_v1_schema_still_loads_with_narrow_fidelity(tmp_path):
    # A nodes.json written by an older turbovec (schema_version=1, narrow
    # `{text, metadata, ref_doc_id}` per entry) must still load — relationships
    # other than SOURCE will be missing (the data wasn't there), but the
    # text + metadata + SOURCE relationship round-trip as they always did.
    import json

    # Build a v1-shaped side-car by hand. We still need the binary index
    # file alongside it, so write a v2 store first and overwrite just
    # the JSON.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = TextNode(
        id_="v1-node",
        text="legacy text",
        metadata={"k": "v"},
        embedding=_unit_vec(0, 64),
        relationships={
            NodeRelationship.SOURCE: RelatedNodeInfo(node_id="legacy-doc"),
        },
    )
    store.add([node])
    persist_path = tmp_path / "store.json"
    store.persist(str(persist_path))

    nodes_path = persist_path.with_suffix(".nodes.json")
    with open(nodes_path) as f:
        state = json.load(f)
    state["schema_version"] = 1
    # Rewrite each entry in the v1 shape: {text, metadata, ref_doc_id} only.
    state["nodes"] = {
        nid: {
            "text": "legacy text",
            "metadata": {"k": "v"},
            "ref_doc_id": "legacy-doc",
        }
        for nid in state["nodes"]
    }
    with open(nodes_path, "w") as f:
        json.dump(state, f)

    loaded = TurboQuantVectorStore.from_persist_path(str(persist_path))
    [restored] = loaded.get_nodes(node_ids=["v1-node"])
    assert restored.get_content() == "legacy text"
    assert restored.metadata == {"k": "v"}
    assert restored.ref_doc_id == "legacy-doc"


def test_query_rejects_non_default_mode():
    # MMR / SVM / hybrid all need full-precision vectors which turbovec
    # discards. Raise loudly instead of silently treating as DEFAULT
    # (which the previous impl did, masking that the requested mode
    # wasn't honoured).
    from llama_index.core.vector_stores.types import VectorStoreQueryMode

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("a", seed=0)])
    q = VectorStoreQuery(
        query_embedding=_unit_vec(0, 64),
        similarity_top_k=1,
        mode=VectorStoreQueryMode.MMR,
    )
    with pytest.raises(NotImplementedError, match="query mode"):
        store.query(q)


# ---- Tier-2 field-completeness tests. ----

def test_add_raises_on_intra_batch_duplicate_node_id():
    # If a single add() call contains two nodes with the same node_id,
    # the prior impl would leave the index with both vectors but only
    # the last node_id mapped back to one — orphaning the first handle
    # and silently returning the second node's payload attached to the
    # first node's vector on later queries. Now raises loudly.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    n1 = TextNode(id_="dup", text="first", embedding=_unit_vec(1, 64))
    n2 = TextNode(id_="dup", text="second", embedding=_unit_vec(2, 64))
    with pytest.raises(ValueError, match="duplicate node_id"):
        store.add([n1, n2])
    # And the store is left in a clean state — no half-written index.
    assert len(store._index) == 0
    assert store._nodes == {}


def test_query_round_trips_image_node_subtype():
    # PR #83 covered TextNode field fidelity exhaustively, but every
    # test uses TextNode. node_to_metadata_dict / metadata_dict_to_node
    # also handle ImageNode — pin that explicitly so a regression in
    # the helper dispatch (or a switch back to bare TextNode
    # reconstruction) gets caught.
    from llama_index.core.schema import ImageNode

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    image_node = ImageNode(
        id_="img-1",
        text="caption",
        image_url="https://example.com/img.png",
        image_mimetype="image/png",
        embedding=_unit_vec(1, 64),
        metadata={"source": "test"},
    )
    store.add([image_node])

    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=1)
    )
    [returned] = result.nodes
    assert isinstance(returned, ImageNode)
    assert returned.id_ == "img-1"
    assert returned.image_url == "https://example.com/img.png"
    assert returned.image_mimetype == "image/png"
    assert returned.metadata == {"source": "test"}


def test_query_round_trips_index_node_subtype():
    # Same fidelity check for IndexNode (used by composable indexes /
    # routers / sub-question pipelines).
    from llama_index.core.schema import IndexNode

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    index_node = IndexNode(
        id_="idx-1",
        text="sub-index pointer",
        index_id="child-index-uuid",
        embedding=_unit_vec(1, 64),
        metadata={"router": "yes"},
    )
    store.add([index_node])

    result = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=1)
    )
    [returned] = result.nodes
    assert isinstance(returned, IndexNode)
    assert returned.id_ == "idx-1"
    assert returned.index_id == "child-index-uuid"
    assert returned.metadata == {"router": "yes"}


def test_query_returned_node_always_has_none_embedding():
    # turbovec discards full-precision embeddings after quantization.
    # `get()` raises NotImplementedError to communicate this; `query`
    # and `get_nodes` honour the same contract by returning nodes with
    # `embedding=None` even when the input node had an embedding set.
    # Pin this so a future refactor doesn't silently start round-
    # tripping the raw float list and contradict the `get()` story.
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([
        _make_node("a", seed=1, metadata={"k": "v"}),
        _make_node("b", seed=2, metadata={"k": "w"}),
    ])

    qresult = store.query(
        VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=2)
    )
    for node in qresult.nodes:
        assert node.embedding is None

    for node in store.get_nodes():
        assert node.embedding is None


# ---- Embedder-output validation (issue #154) ------------------------------


def test_add_empty_embeddings_raise_error_naming_embed_model():
    # Nodes whose embed model produced empty vectors form a (N, 0) batch —
    # 2D, so it slipped the ndim guard and died downstream with
    # "vector buffer length 0 not a multiple of dim 0" on main.
    store = TurboQuantVectorStore()
    nodes = [TextNode(text=f"t{i}", embedding=[]) for i in range(3)]
    with pytest.raises(ValueError, match=r"empty embeddings \(dim 0\).*embed model"):
        store.add(nodes)
    assert len(store._nodes) == 0


def test_from_persist_path_rejects_side_car_desynced_from_index(tmp_path):
    import json

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node(t, seed=i) for i, t in enumerate(["a", "b", "c", "d"])])
    base = str(tmp_path / "store")
    store.persist(base)

    TurboQuantVectorStore.from_persist_path(base)  # clean reload works

    side_car = tmp_path / "store.nodes.json"
    with open(side_car) as f:
        state = json.load(f)
    state["node_id_to_u64"] = state["node_id_to_u64"][:-1]  # drop one node->handle
    with open(side_car, "w") as f:
        json.dump(state, f)

    with pytest.raises(ValueError):
        TurboQuantVectorStore.from_persist_path(base)


def test_from_persist_path_rejects_nodes_desynced_from_id_map(tmp_path):
    # Issue #133: the `nodes` object lost an entry while `node_id_to_u64`
    # (and the index) kept it. The handle↔index check passes, so without a
    # key-set check this loads clean and raises a bare KeyError inside the
    # first query that hits the missing node.
    import json

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node(t, seed=i) for i, t in enumerate(["a", "b", "c"])])
    base = str(tmp_path / "store")
    store.persist(base)

    TurboQuantVectorStore.from_persist_path(base)  # clean reload works

    side_car = tmp_path / "store.nodes.json"
    with open(side_car) as f:
        state = json.load(f)
    # Drop one node payload, leaving node_id_to_u64 and the index intact.
    del state["nodes"][next(iter(state["nodes"]))]
    with open(side_car, "w") as f:
        json.dump(state, f)

    with pytest.raises(ValueError, match="missing from `nodes`"):
        TurboQuantVectorStore.from_persist_path(base)


def test_from_persist_path_rejects_node_entry_without_id_mapping(tmp_path):
    # Reverse desync direction: a `nodes` entry with no `node_id_to_u64`
    # mapping. Such a node would surface from get_nodes but be invisible
    # to query and delete — reject it at load instead.
    import json

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node(t, seed=i) for i, t in enumerate(["a", "b"])])
    base = str(tmp_path / "store")
    store.persist(base)

    side_car = tmp_path / "store.nodes.json"
    with open(side_car) as f:
        state = json.load(f)
    state["nodes"]["ghost"] = next(iter(state["nodes"].values()))
    with open(side_car, "w") as f:
        json.dump(state, f)

    with pytest.raises(ValueError, match="missing from `node_id_to_u64`"):
        TurboQuantVectorStore.from_persist_path(base)


def test_from_persist_path_rejects_duplicate_handles_in_id_map(tmp_path):
    # Two node ids mapped to the same handle silently collapse in the
    # inverse (u64 -> node_id) map; the id map must be 1:1 to trust
    # either direction.
    import json

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node(t, seed=i) for i, t in enumerate(["a", "b", "c"])])
    base = str(tmp_path / "store")
    store.persist(base)

    side_car = tmp_path / "store.nodes.json"
    with open(side_car) as f:
        state = json.load(f)
    state["node_id_to_u64"][1][1] = state["node_id_to_u64"][0][1]
    with open(side_car, "w") as f:
        json.dump(state, f)

    with pytest.raises(ValueError, match="duplicate node handles"):
        TurboQuantVectorStore.from_persist_path(base)


def test_from_persist_path_rejects_collapsed_id_map_with_truncated_index(tmp_path):
    # Consistent-truncation variant of the duplicate-handle corruption:
    # the id map collapsed (two node ids sharing one handle) AND the
    # index lost the orphaned vector, so the surviving handle set still
    # matches the index and the handle-count check alone passes. Without
    # the explicit 1:1 check this loaded clean and one node was silently
    # aliased to another node's vector.
    import json

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node(t, seed=i) for i, t in enumerate(["a", "b", "c"])])
    base = str(tmp_path / "store")
    store.persist(base)

    side_car = tmp_path / "store.nodes.json"
    with open(side_car) as f:
        state = json.load(f)
    # Collapse: the second node id now shares the first node's handle...
    orphaned = state["node_id_to_u64"][1][1]
    state["node_id_to_u64"][1][1] = state["node_id_to_u64"][0][1]
    with open(side_car, "w") as f:
        json.dump(state, f)
    # ...and truncate the index to match by dropping the orphaned handle.
    index_path = str(tmp_path / "store.tvim")
    index = IdMapIndex.load(index_path)
    index.remove(orphaned)
    index.write(index_path)

    with pytest.raises(ValueError, match="duplicate node handles"):
        TurboQuantVectorStore.from_persist_path(base)


def test_delete_none_is_a_noop_matching_reference():
    # Issue #302: `delete(None)` used to match every parentless node
    # (their stored ref_doc_id is None) and wipe them. The reference
    # `SimpleVectorStore` files a parentless node under the literal
    # string "None" (`node.ref_doc_id or "None"`), so `delete(None)`
    # matches nothing there. Compare side by side.
    from llama_index.core.vector_stores.simple import SimpleVectorStore

    def _corpus():
        return [
            _make_node("n0", seed=0, ref_doc_id="doc"),
            _make_node("n1", seed=1),
            _make_node("n2", seed=2),
        ]

    ours = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    our_nodes = _corpus()
    ours.add(our_nodes)

    ref = SimpleVectorStore()
    ref_nodes = _corpus()
    ref.add(ref_nodes)

    ours.delete(None)
    ref.delete(None)

    surviving = {n.get_content() for n in ours.get_nodes()}
    ref_surviving = {
        node.get_content()
        for node in ref_nodes
        if node.node_id in ref.data.embedding_dict
    }
    assert surviving == ref_surviving == {"n0", "n1", "n2"}


def test_delete_literal_none_string_targets_parentless_nodes():
    # The reference's flip side: "None" is how a caller addresses the
    # parentless nodes (issue #302).
    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add(
        [
            _make_node("n0", seed=0, ref_doc_id="doc"),
            _make_node("n1", seed=1),
            _make_node("n2", seed=2),
        ]
    )
    store.delete("None")
    assert {n.get_content() for n in store.get_nodes()} == {"n0"}
    # A real ref_doc_id still works as before.
    store.delete("doc")
    assert store.get_nodes() == []


def test_from_persist_dir_rejects_a_rewound_next_u64_watermark(tmp_path):
    # Issue #321: shared `_persist` watermark check, llama_index load path.
    import json

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node(t, seed=i) for i, t in enumerate(["a", "b", "c"])])
    store.persist(str(tmp_path / "default__vector_store.json"))

    side_car = tmp_path / "default__vector_store.nodes.json"
    state = json.loads(side_car.read_text())
    assert state["next_u64"] >= 3
    state["next_u64"] = 0
    side_car.write_text(json.dumps(state))

    with pytest.raises(ValueError, match="next_u64"):
        TurboQuantVectorStore.from_persist_dir(str(tmp_path))


def test_filters_operate_on_the_metadata_that_is_returned(tmp_path):
    """The store filtered raw Python metadata but returned the JSON-coerced
    copy, so a filter could match a value the caller never sees — and,
    because persist() re-coerces, the same filter changed answers across a
    save/reload cycle (#497). SimpleVectorStore stores and filters the
    coerced dict; this pins that we do the same."""
    import datetime

    from llama_index.core.vector_stores.types import (
        FilterOperator,
        MetadataFilter,
        MetadataFilters,
        VectorStoreQuery,
    )

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    node = _make_node("tup", seed=1, metadata={"tags": ("a", "b"), "n": 3})
    store.add([node])

    # What is stored for filtering must be what a query hands back.
    stored = list(store._nodes.values())[0]["metadata"]
    q = VectorStoreQuery(query_embedding=_unit_vec(1, 64), similarity_top_k=1)
    returned = store.query(q).nodes[0]
    assert stored == returned.metadata, (
        f"filtered-on {stored!r} but returned {returned.metadata!r}"
    )
    # And it is the coerced shape, not the raw tuple.
    assert stored["tags"] == ["a", "b"]

    # A filter written against the returned value matches.
    flt = MetadataFilters(
        filters=[MetadataFilter(key="tags", value=["a", "b"], operator=FilterOperator.EQ)]
    )
    q2 = VectorStoreQuery(
        query_embedding=_unit_vec(1, 64), similarity_top_k=5, filters=flt
    )
    assert len(store.query(q2).nodes) == 1

    # Persist-invariance: the same filter must give the same answer after
    # a reload, which is what the raw/coerced split broke.
    p = tmp_path / "s.json"
    store.persist(str(p))
    reloaded = TurboQuantVectorStore.from_persist_path(str(p))
    assert len(reloaded.query(q2).nodes) == 1
    assert list(reloaded._nodes.values())[0]["metadata"] == stored


def test_datetime_metadata_round_trips_consistently(tmp_path):
    """A datetime is coerced to an ISO string on the way out; the filter
    side must agree, before and after a persist (#497)."""
    import datetime

    from llama_index.core.vector_stores.types import VectorStoreQuery

    from llama_index.core.vector_stores.utils import node_to_metadata_dict

    when = datetime.datetime(2020, 1, 1, 12, 0, 0)
    probe = _make_node("probe", seed=99, metadata={"when": when})
    try:
        node_to_metadata_dict(probe, remove_text=False, flat_metadata=False)
    except TypeError:
        pytest.skip(
            "this llama-index-core version serializes node content eagerly at "
            "add() time and rejects a datetime in metadata outright, so there "
            "is no stored value to compare"
        )

    store = TurboQuantVectorStore.from_params(dim=64, bit_width=4)
    store.add([_make_node("dt", seed=2, metadata={"when": when})])

    payload = list(store._nodes.values())[0]
    stored = payload["metadata"]["when"]
    q = VectorStoreQuery(query_embedding=_unit_vec(2, 64), similarity_top_k=1)
    returned = store.query(q).nodes[0].metadata["when"]

    # The consistency this issue is about holds at every version: what is
    # filtered is what is returned, coerced or not.
    assert stored == returned, f"stored {stored!r} but returned {returned!r}"

    # Whether a datetime becomes an ISO string is llama-index's decision,
    # not ours — at the declared floor it coerces nothing, so both sides
    # keep the raw value and a store holding one cannot be persisted at
    # all. Gate the coercion-specific assertions on the installed
    # version actually coercing, the same way this file gates
    # TEXT_MATCH_INSENSITIVE and FilterCondition.NOT.
    if not isinstance(stored, str):
        pytest.skip(
            "this llama-index-core version does not coerce datetimes in node "
            "metadata; stored and returned both keep the raw value, which is "
            "still self-consistent"
        )
    json.dumps(payload)

    p = tmp_path / "d.json"
    store.persist(str(p))
    reloaded = TurboQuantVectorStore.from_persist_path(str(p))
    assert list(reloaded._nodes.values())[0]["metadata"]["when"] == stored
