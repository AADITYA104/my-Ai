"""Tests for the Agno VectorDb integration."""
from __future__ import annotations

import copy as _copy
import json

import numpy as np
import pytest

pytest.importorskip("agno")

from agno.knowledge.document import Document
from agno.vectordb.distance import Distance
from agno.vectordb.search import SearchType

from turbovec.agno import TurboQuantVectorDb


DIM = 64


class StubEmbedder:
    """Deterministic Agno-style embedder for tests.

    Implements the minimal embedder surface the integration uses:
    ``dimensions`` attribute, ``get_embedding(text)`` method,
    ``enable_batch`` attribute (False — we don't exercise batch).
    """

    enable_batch = False

    def __init__(self, dim: int = DIM) -> None:
        self.dimensions = dim

    def _embed(self, text: str) -> list[float]:
        rng = np.random.default_rng(abs(hash(text)) % (2**32))
        v = rng.standard_normal(self.dimensions).astype(np.float32)
        v /= np.linalg.norm(v) + 1e-9
        return v.tolist()

    def get_embedding(self, text: str) -> list[float]:
        return self._embed(text)

    async def async_get_embedding(self, text: str) -> list[float]:
        return self._embed(text)


def _doc(content: str, *, doc_id: str | None = None, name: str | None = None,
         meta_data: dict | None = None, content_id: str | None = None,
         pre_embed: bool = True) -> Document:
    embedder = StubEmbedder(DIM)
    return Document(
        id=doc_id,
        name=name,
        content=content,
        meta_data=meta_data or {},
        content_id=content_id,
        embedding=embedder._embed(content) if pre_embed else None,
    )


class BatchEmbedder(StubEmbedder):
    """Embedder that advertises ``enable_batch`` and exposes both sync
    and async batch methods. Used to verify the integration takes the
    batch path when it's available."""

    enable_batch = True

    def __init__(self, dim: int = DIM) -> None:
        super().__init__(dim)
        self.sync_batch_calls = 0
        self.async_batch_calls = 0

    def get_embeddings_batch_and_usage(self, texts):
        self.sync_batch_calls += 1
        return [self._embed(t) for t in texts], [{"tokens": 1} for _ in texts]

    async def async_get_embeddings_batch_and_usage(self, texts):
        self.async_batch_calls += 1
        return [self._embed(t) for t in texts], [{"tokens": 1} for _ in texts]


from agno.knowledge.reranker.base import Reranker as _AgnoReranker


class ReverseReranker(_AgnoReranker):
    """Trivial reranker that returns documents in reversed order. Used
    to verify the integration calls .rerank() on the result list."""

    calls: int = 0

    def rerank(self, query: str, documents):
        type(self).calls += 1
        return list(reversed(documents))


# ---- Constructor validation -----------------------------------------------


def test_search_results_carry_embedder():
    # Match LanceDb._build_search_results — returned Documents must have
    # `embedder` set to the store's embedder so downstream code can call
    # `doc.embed()` / `doc.async_embed()` on a retrieved hit. Without
    # the field set, `Document.embed` raises "No embedder provided".
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [_doc("hello", doc_id="d-1")])
    [result] = db.search(query="hello", limit=1)
    assert result.embedder is embedder


async def _async_search_embedder_body():
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [_doc("hello", doc_id="d-1")])
    [result] = await db.async_search(query="hello", limit=1)
    assert result.embedder is embedder


def test_async_search_results_also_carry_embedder():
    import asyncio
    asyncio.run(_async_search_embedder_body())


# ---- Reference-parity tests against agno's LanceDb test suite. Each
# pins behaviour the in-tree LanceDb unit tests exercise. ----

def test_update_metadata_updates_all_docs_sharing_content_id():
    # `content_id` is intentionally many-to-one — `update_metadata(cid, m)`
    # must update every doc with that cid, not just the first match. The
    # LanceDb reference covers this; our existing test only inserts one
    # doc per content_id and wouldn't have caught a "first-match only" bug.
    # Identify docs by a `label` in meta_data since agno's _derive_doc_id
    # rewrites doc.id at insert time.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [
        _doc("a", content_id="shared", meta_data={"label": "first"}),
        _doc("b", content_id="shared", meta_data={"label": "second"}),
        _doc("c", content_id="other", meta_data={"label": "third"}),
    ])
    db.update_metadata("shared", {"updated": True})

    results = db.search("a", limit=10)
    by_label = {d.meta_data["label"]: d for d in results}
    assert by_label["first"].meta_data.get("updated") is True
    assert by_label["second"].meta_data.get("updated") is True
    assert by_label["third"].meta_data.get("updated") is None


def test_update_metadata_preserves_quantized_codes():
    # `update_metadata` must not re-derive codes — codes are precious
    # (cost an embed + a quantise) and a silent re-embed would also
    # break determinism. Behaviour-level check: search results are
    # bit-identical before and after a metadata update.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [
        _doc(f"doc-{i}", doc_id=f"d-{i}", content_id=f"cid-{i}") for i in range(3)
    ])

    before = db.search("doc-0", limit=3)
    db.update_metadata("cid-0", {"updated": True})
    after = db.search("doc-0", limit=3)
    assert [d.id for d in before] == [d.id for d in after]


def test_insert_reembeds_document_with_empty_list_embedding():
    # In agno's async pipeline, failed embeds surface as `embedding=[]`
    # (an empty list, distinct path from None). The integration must
    # re-embed those rather than silently skipping or shipping the
    # zero-length vector to the kernel. Uses BatchEmbedder so we have
    # an embedder with the batch path the re-embed code prefers.
    embedder = BatchEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    doc = Document(id="d-1", content="hello", embedding=[], meta_data={})
    db.insert("h", [doc])
    assert db.get_count() == 1


def test_insert_accepts_numpy_array_embedding():
    # Regression test for issue #135: a numpy-array embedding hit
    # `if not doc.embedding`, raising the numpy truth-value-ambiguous
    # ValueError. LanceDb tolerates array embeddings; so must we.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    vec = np.asarray(embedder.get_embedding("x"), dtype=np.float32)
    db.insert("h-np", [Document(id="d1", content="x", embedding=vec)])
    assert db.get_count() == 1
    [hit] = db.search("x", limit=1)
    assert hit.content == "x"


def test_upsert_accepts_numpy_array_embedding():
    # Same ndarray-tolerance for the upsert path (issue #135).
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    vec = np.asarray(embedder.get_embedding("y"), dtype=np.float32)
    db.upsert("h-np", [Document(id="d1", content="y", embedding=vec)])
    assert db.get_count() == 1


def test_insert_empty_document_list_is_noop():
    # Drop-in safety: callers passing an empty list (e.g. a Knowledge
    # batch where every doc was filtered out upstream) must not raise
    # and must not change store state.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [])
    assert db.get_count() == 0


def test_search_with_empty_query_returns_empty():
    # LanceDb short-circuits `search("")` to []. Without this, a hash-
    # derived embedding of "" would return arbitrary near-match garbage.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [_doc("a", doc_id="d-1")])
    assert db.search("", limit=5) == []
    # None also short-circuits (defensive against upstream un-init).
    assert db.search(None, limit=5) == []  # type: ignore[arg-type]


def test_delete_by_metadata_handles_non_string_values():
    # `delete_by_metadata` matches on equality across heterogeneous
    # value types — bools, floats, ints. JSON round-trip during persist
    # could coerce types (`True` → `"true"`); the in-memory path must
    # at minimum work natively. Identify docs by `label` since agno's
    # _derive_doc_id rewrites doc.id at insert time.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [
        _doc("a", meta_data={"active": True, "score": 0.9, "label": "x"}),
        _doc("b", meta_data={"active": False, "score": 0.9, "label": "y"}),
        _doc("c", meta_data={"active": True, "score": 0.5, "label": "z"}),
    ])
    db.delete_by_metadata({"active": True})
    labels = {d.meta_data["label"] for d in db.search("a", limit=10)}
    assert labels == {"y"}


def test_update_metadata_with_empty_dict_is_noop():
    # `update_metadata(cid, {})` must not raise and must not strip the
    # existing metadata — empty dict is a real edge case (e.g. a caller
    # built `metadata` from filtered keys and ended up with no updates).
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [_doc("a", doc_id="d-1", content_id="cid-1", meta_data={"k": "v"})])
    db.update_metadata("cid-1", {})

    results = db.search("a", limit=1)
    assert results[0].meta_data == {"k": "v"}


def test_search_dedupes_duplicate_content_keeping_first():
    # LanceDb parity (issue #136): LanceDb.search unconditionally
    # deduplicates the final result list by md5(doc.content), keeping
    # the first occurrence. The realistic way an agno user hits this:
    # the same paragraph appears in two knowledge sources, so it's
    # inserted under two content_hashes — the derived doc_ids differ,
    # both rows coexist in the store, and search must collapse them.
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("hash-a", [_doc("same text here", name="n1")])
    db.insert("hash-b", [_doc("same text here", name="n2", meta_data={"src": "b"})])
    db.insert("hash-c", [_doc("other doc entirely", name="n3")])

    results = db.search("same text here", limit=5)
    # Hand-computed LanceDb-semantics expectation: 3 raw hits ordered by
    # score -> md5(content)-dedup keeps the first (highest-scoring)
    # "same text here" plus the distinct doc.
    assert [d.content for d in results] == ["same text here", "other doc entirely"]
    assert results[0].name == "n1"  # first occurrence kept, n2 dropped


def test_search_dedup_can_return_fewer_than_limit():
    # LanceDb parity (issue #136): LanceDb fetches `limit` results and
    # THEN dedups, so callers can receive fewer than `limit` documents
    # when duplicates exist. We deliberately replicate that — no
    # over-fetch to refill the result set back up to `limit`.
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("hash-a", [_doc("duplicated text", name="n1")])
    db.insert("hash-b", [_doc("duplicated text", name="n2")])

    results = db.search("duplicated text", limit=2)
    assert len(results) == 1  # fewer than limit=2 — pinned, not a bug


def test_search_distinct_content_unaffected_by_dedup():
    # Dedup keys on md5(content); distinct-content docs all survive.
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("h", [
        _doc("alpha text", content_id="cid-1"),
        _doc("beta text", content_id="cid-2"),
        _doc("gamma text", content_id="cid-3"),
    ])
    results = db.search("alpha text", limit=10)
    assert len(results) == 3
    assert {d.content_id for d in results} == {"cid-1", "cid-2", "cid-3"}


def test_async_search_dedupes_duplicate_content():
    # async_search has its own body (it doesn't delegate to search), so
    # pin the same LanceDb dedup semantics on the async path too.
    import asyncio

    async def runner():
        db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
        db.create()
        db.insert("hash-a", [_doc("same text here", name="n1")])
        db.insert("hash-b", [_doc("same text here", name="n2")])
        db.insert("hash-c", [_doc("other doc entirely", name="n3")])
        results = await db.async_search("same text here", limit=5)
        assert [d.content for d in results] == [
            "same text here",
            "other doc entirely",
        ]

    asyncio.run(runner())


def test_search_dedup_applied_after_rerank():
    # LanceDb's ordering is filter -> rerank -> dedup: the reranker sees
    # the full pre-dedup hit list, and dedup collapses the *reranked*
    # order. Pin that the reranker receives all raw hits while the
    # caller receives the deduped list.
    class CapturingReranker(_AgnoReranker):
        seen: int = 0

        def rerank(self, query: str, documents):
            type(self).seen = len(documents)
            return list(documents)

    db = TurboQuantVectorDb(
        embedder=StubEmbedder(DIM), reranker=CapturingReranker()
    )
    db.create()
    db.insert("hash-a", [_doc("same text here", name="n1")])
    db.insert("hash-b", [_doc("same text here", name="n2")])
    db.insert("hash-c", [_doc("other doc entirely", name="n3")])

    results = db.search("same text here", limit=5)
    assert CapturingReranker.seen == 3  # reranker saw the pre-dedup list
    assert len(results) == 2


def test_upsert_replaces_previous_generation():
    # A valid upsert under the same content_hash replaces the previous
    # generation entirely (deferred handle-based removal after the add).
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.upsert("h1", [_doc("v1", content_id="cid-1")])
    db.upsert("h1", [_doc("v2", content_id="cid-1")])

    assert len(db._u64_to_doc) == 1
    contents = [r.content for r in db.search("v2", limit=10)]
    assert "v2" in contents
    assert "v1" not in contents


def test_upsert_dim_mismatch_preserves_existing():
    # An upsert whose new embeddings fail validation must not destroy the
    # data being replaced: the old generation is removed only after the
    # insert succeeds (issue #89).
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.upsert("h1", [_doc("orig", content_id="cid-1")])

    bad = Document(content="new", meta_data={}, content_id="cid-1",
                   embedding=[0.1] * 32)
    with pytest.raises(ValueError):
        db.upsert("h1", [bad])  # dim 32 != index dim 64

    results = db.search("orig", limit=5)
    assert len(results) == 1
    assert results[0].content == "orig"
    assert len(db._u64_to_doc) == 1


def test_constructor_requires_embedder():
    with pytest.raises(ValueError, match="embedder.*required"):
        TurboQuantVectorDb()


def test_constructor_rejects_embedder_without_dimensions():
    class NoDimEmbedder:
        dimensions = None
        enable_batch = False
        def get_embedding(self, t): return [0.0] * 64

    with pytest.raises(ValueError, match="dimensions"):
        TurboQuantVectorDb(embedder=NoDimEmbedder())


def test_constructor_rejects_keyword_search_type():
    with pytest.raises(ValueError, match="search_type"):
        TurboQuantVectorDb(embedder=StubEmbedder(), search_type=SearchType.keyword)


def test_constructor_rejects_non_cosine_distance():
    with pytest.raises(ValueError, match="distance"):
        TurboQuantVectorDb(embedder=StubEmbedder(), distance=Distance.l2)


@pytest.mark.parametrize("bad", [1, 5, 8])
def test_constructor_rejects_invalid_bit_width(bad):
    with pytest.raises(ValueError, match="bit_width"):
        TurboQuantVectorDb(embedder=StubEmbedder(), bit_width=bad)


def test_constructor_accepts_bit_width_3_round_trip():
    # bit_width contract is {2, 3, 4}, matching the core IdMapIndex.
    db = TurboQuantVectorDb(embedder=StubEmbedder(), bit_width=3)
    db.create()
    db.insert("h", [_doc("alpha"), _doc("beta"), _doc("gamma")])
    [hit] = db.search("alpha", limit=1)
    assert hit.content == "alpha"


def test_dim_inferred_from_embedder():
    db = TurboQuantVectorDb(embedder=StubEmbedder(dim=128))
    assert db.dimensions == 128
    # The underlying index isn't constructed until create() (LanceDb's
    # contract: store object exists, but the "table" doesn't until you
    # ask for it). dim is on the embedder regardless.
    assert db._index is None
    db.create()
    assert db._index.dim == 128


# ---- Lifecycle (create / exists / drop / delete / get_count) -------------


def test_exists_false_until_create():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    assert db.exists() is False
    db.create()
    assert db.exists() is True


def test_create_is_idempotent():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    first_index = db._index
    db.create()
    # Second call doesn't blow away the existing index.
    assert db._index is first_index


def test_drop_returns_to_uncreated_state():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a")])
    assert db.exists() is True
    db.drop()
    assert db.exists() is False
    assert db._index is None
    # Re-create works and gives a fresh store.
    db.create()
    assert db.exists() is True
    assert db.get_count() == 0


def test_drop_with_path_removes_persisted_artifacts(tmp_path):
    # Regression test for issue #169: drop() on a store with a
    # persistence path cleared memory but left index.tvim/docstore.json
    # on disk, so the next create() reloaded — resurrecting — the
    # "dropped" data. drop() must remove the persisted table entirely,
    # matching its docstring and LanceDb's drop_table.
    path = str(tmp_path / "store")
    db = TurboQuantVectorDb(embedder=StubEmbedder(), path=path)
    db.create()
    db.insert("h", [_doc("secret")])
    db.save()
    assert (tmp_path / "store" / "index.tvim").exists()
    assert (tmp_path / "store" / "docstore.json").exists()

    db.drop()
    assert db.exists() is False
    assert not (tmp_path / "store" / "index.tvim").exists()
    assert not (tmp_path / "store" / "docstore.json").exists()
    # Re-create starts empty instead of reloading the dropped data.
    db.create()
    assert db.get_count() == 0


def test_delete_returns_false_per_lancedb_contract():
    # LanceDb's delete() unconditionally returns False — actual removal
    # is via drop(). Mirror that exactly.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a")])
    assert db.delete() is False
    # delete() is a no-op; the index is still there.
    assert db.exists() is True


def test_get_count():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    assert db.get_count() == 0  # before create
    db.create()
    assert db.get_count() == 0  # empty after create
    db.insert("h", [_doc("a"), _doc("b"), _doc("c")])
    assert db.get_count() == 3


def test_optimize_is_noop():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    # Must not raise NotImplementedError (which the base class does).
    db.optimize()


def test_insert_before_create_raises():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    with pytest.raises(RuntimeError, match="not initialized"):
        db.insert("h", [_doc("a")])


def test_search_before_create_returns_empty():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    assert db.search("anything", limit=5) == []


def test_delete_methods_before_create_return_false():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    assert db.delete_by_id("x") is False
    assert db.delete_by_name("x") is False
    assert db.delete_by_metadata({"a": 1}) is False
    assert db.delete_by_content_id("x") is False


# ---- Basic insert / search ------------------------------------------------


def test_create_initializes_store():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    assert db.exists() is False
    db.create()
    assert db.exists() is True
    assert db._index.dim == DIM
    assert db.get_count() == 0


def test_insert_and_search_returns_documents():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("hash-1", [_doc("alpha"), _doc("beta"), _doc("gamma")])
    assert db.exists() is True
    results = db.search("alpha", limit=2)
    assert len(results) == 2
    assert all(isinstance(r, Document) for r in results)


def test_insert_raises_on_document_without_embedding():
    # When the embedder can't produce an embedding (returns None), insert
    # must raise rather than silently dropping the document.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()

    class FailingEmbedder:
        dimensions = DIM
        enable_batch = False
        # Document.embed() actually goes through get_embedding_and_usage.
        def get_embedding(self, t): return None
        def get_embedding_and_usage(self, t): return None, None

    db.embedder = FailingEmbedder()
    no_emb = _doc("x", pre_embed=False)
    no_emb.embedding = None
    with pytest.raises(ValueError, match="failed to embed"):
        db.insert("h", [no_emb])


def test_insert_batches_into_single_add_call():
    # Exercising a batch larger than one. We can't directly observe that the
    # underlying add_with_ids was called once, but we can confirm the result
    # is correct and the index size is right.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    docs = [_doc(f"text-{i}", doc_id=f"d-{i}") for i in range(8)]
    db.insert("hash-batch", docs)
    assert len(db._index) == 8


# ---- Existence checks -----------------------------------------------------


def test_name_exists():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("content", name="my-file.pdf")])
    assert db.name_exists("my-file.pdf") is True
    assert db.name_exists("nope.pdf") is False


def test_id_exists_uses_derived_id():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("content", doc_id="base-id")])
    # id_exists must use the *derived* id (md5(base_id + content_hash)),
    # not the input id directly.
    derived = next(iter(db._str_to_u64.keys()))
    assert db.id_exists(derived) is True
    assert db.id_exists("base-id") is False


def test_content_hash_exists_o1():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("unique-hash", [_doc("x")])
    assert db.content_hash_exists("unique-hash") is True
    assert db.content_hash_exists("other-hash") is False


# ---- Filters (kernel allowlist) -------------------------------------------


def test_search_with_metadata_filter():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    docs = [
        _doc("alpha", doc_id="a", meta_data={"tag": "keep"}),
        _doc("beta",  doc_id="b", meta_data={"tag": "drop"}),
        _doc("gamma", doc_id="g", meta_data={"tag": "keep"}),
    ]
    db.insert("h", docs)
    results = db.search("alpha", limit=10, filters={"tag": "keep"})
    assert len(results) == 2
    assert all(r.meta_data["tag"] == "keep" for r in results)


def test_search_with_selective_filter_returns_top_k():
    # Regression for the over-fetch / post-filter recall hit: filter that
    # matches 3 of 50 docs with limit=3 must return all 3, even when those
    # docs aren't in the unfiltered top-3 by raw score.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    docs = []
    for i in range(50):
        meta = {"tag": "needle"} if i in (7, 23, 41) else {"tag": "hay"}
        docs.append(_doc(f"text-{i}", doc_id=f"d-{i}", meta_data=meta))
    db.insert("h", docs)
    results = db.search("text-0", limit=3, filters={"tag": "needle"})
    assert len(results) == 3
    assert all(r.meta_data["tag"] == "needle" for r in results)


def test_search_with_no_matching_filter_returns_empty():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("alpha", meta_data={"tag": "a"})])
    results = db.search("alpha", limit=5, filters={"tag": "nonexistent"})
    assert results == []


def test_search_filter_none_value_requires_key_present():
    # Regression test for issue #144: `{"k": None}` must match only docs
    # where the key is PRESENT and equal to None (LanceDb semantics).
    # `.get(k) == v` coerced key-absence to None, so filtering on an
    # unset field leaked the entire collection.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [
        _doc("a", meta_data={"x": "v"}),
        _doc("b", meta_data={}),
        _doc("d", meta_data={"x": None}),
    ])
    hits = db.search("a", limit=10, filters={"x": None})
    assert sorted(h.content for h in hits) == ["d"]
    # Filtering on a key no document has must match nothing, not everything.
    assert db.search("a", limit=10, filters={"missing": None}) == []


def test_search_list_filter_silently_ignored():
    # Match LanceDb behavior: list-of-FilterExpr filters are ignored.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b")])
    results = db.search("a", limit=2, filters=["something"])
    assert len(results) == 2  # filter ignored, full search


# ---- Similarity threshold -------------------------------------------------


def test_similarity_threshold_filters_low_scores():
    # similarity_threshold drops results whose scaled cosine is below
    # the threshold. Use a generous margin: the StubEmbedder produces
    # vectors that hash random text to roughly orthogonal directions
    # (raw cosine near 0 -> scaled ~0.5), so threshold=0.9 reliably
    # excludes the unrelated doc while letting the self-match through.
    db = TurboQuantVectorDb(embedder=StubEmbedder(), similarity_threshold=0.9)
    db.create()
    db.insert("h", [_doc("alpha"), _doc("very different content here")])
    results = db.search("alpha", limit=5)
    # Self-match scales to ~1.0; the unrelated doc to ~0.5. Threshold
    # filters out the unrelated one.
    assert len(results) >= 1
    assert all(r.content == "alpha" for r in results)


# ---- Upsert ---------------------------------------------------------------


def test_upsert_replaces_entire_batch_under_content_hash():
    # LanceDb's contract: upsert deletes EVERY existing document under
    # the given content_hash before inserting the new batch. The unit of
    # replacement is the content_hash, not the doc_id.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h-v1", [_doc("a"), _doc("b"), _doc("c")])
    assert db.get_count() == 3
    # Re-upsert under the same content_hash with a smaller batch — the
    # original 3 docs go away and only the new ones remain.
    db.upsert("h-v1", [_doc("z")])
    assert db.get_count() == 1


def test_upsert_distinct_content_hashes_keep_separate_entries():
    # The doc_id is derived from (base_id, content_hash). Different
    # content_hashes don't collide, so upserting under a new hash leaves
    # existing entries alone.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.upsert("hash-A", [_doc("x", doc_id="same-base")])
    db.upsert("hash-B", [_doc("x", doc_id="same-base")])
    assert db.get_count() == 2


# ---- Delete ---------------------------------------------------------------


def test_delete_by_id_returns_bool():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a", doc_id="x")])
    derived = next(iter(db._str_to_u64.keys()))
    assert db.delete_by_id(derived) is True
    assert db.delete_by_id("nonexistent") is False
    assert len(db._index) == 0


def test_delete_by_name_removes_all_matching():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [
        _doc("a", name="paper.pdf"),
        _doc("b", name="paper.pdf"),
        _doc("c", name="other.pdf"),
    ])
    assert db.delete_by_name("paper.pdf") is True
    assert db.delete_by_name("paper.pdf") is False  # already gone
    assert len(db._index) == 1


def test_delete_by_metadata_uses_and_semantics():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [
        _doc("a", meta_data={"tag": "x", "src": "web"}),
        _doc("b", meta_data={"tag": "x", "src": "pdf"}),
        _doc("c", meta_data={"tag": "y", "src": "web"}),
    ])
    assert db.delete_by_metadata({"tag": "x", "src": "web"}) is True
    assert len(db._index) == 2


def test_delete_by_metadata_empty_dict_deletes_all():
    # Pin the documented behavior: an empty dict is a vacuous AND, so it
    # matches — and deletes — every document. This is exact LanceDb
    # parity (its match loop over zero conditions also matches all).
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b"), _doc("c")])
    assert db.delete_by_metadata({}) is True
    assert db.get_count() == 0


def test_delete_by_metadata_none_returns_false():
    # None is off-contract (param typed dict). LanceDb's except-all
    # swallows the resulting AttributeError and returns False; guard
    # explicitly instead of raising.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a")])
    assert db.delete_by_metadata(None) is False
    assert db.get_count() == 1


def test_delete_by_name_none_is_noop():
    # Same footgun class as delete_by_content_id(None): docs stored
    # without a name keep it as None, so a None argument would delete
    # every unnamed doc. Deliberate divergence from LanceDb's idiom —
    # no-op instead.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b")])  # no name on either
    assert db.delete_by_name(None) is False
    assert db.get_count() == 2


def test_delete_by_metadata_none_value_requires_key_present():
    # Regression test for issue #144 (delete sibling): a None-valued
    # delete filter must delete only docs where the key is present and
    # None — not every doc missing the key (which over-deleted the
    # whole collection via `.get(k) == v`).
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [
        _doc("a", meta_data={"x": "v"}),
        _doc("b", meta_data={}),
        _doc("d", meta_data={"x": None}),
    ])
    assert db.delete_by_metadata({"x": None}) is True
    assert len(db._index) == 2  # only "d" removed
    assert db.delete_by_metadata({"missing": None}) is False
    assert len(db._index) == 2  # nothing else removed


def test_delete_by_content_id():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [
        _doc("a", content_id="cid-1"),
        _doc("b", content_id="cid-2"),
    ])
    assert db.delete_by_content_id("cid-1") is True
    assert db.delete_by_content_id("cid-1") is False
    assert len(db._index) == 1


def test_drop_clears_all_state():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a", name="foo")])
    db.drop()
    # drop() releases the underlying index; exists() goes back to False.
    assert db._index is None
    assert db._str_to_u64 == {}
    assert db._u64_to_doc == {}
    assert db._content_hashes == set()
    assert db._name_to_ids == {}


# ---- update_metadata ------------------------------------------------------


def test_update_metadata_merges_by_content_id():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a", content_id="cid", meta_data={"old": 1})])
    db.update_metadata("cid", {"new": 2})
    docs = list(db._u64_to_doc.values())
    assert docs[0]["meta_data"] == {"old": 1, "new": 2}


def test_update_metadata_writes_filters_field():
    # LanceDb's update_metadata writes to BOTH `meta_data` and a separate
    # `filters` payload field. Mirror that — drop-in callers reading the
    # filters field after an update expect to find it.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a", content_id="cid", meta_data={"old": 1})])
    db.update_metadata("cid", {"new": 2})
    docs = list(db._u64_to_doc.values())
    assert docs[0]["filters"] == {"new": 2}


# ---- Persistence ---------------------------------------------------------


def test_save_writes_json_sidecar(tmp_path):
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a", doc_id="x"), _doc("b", doc_id="y")])
    db.save(str(tmp_path))
    assert (tmp_path / "index.tvim").exists()
    assert (tmp_path / "docstore.json").exists()
    assert not (tmp_path / "docstore.pkl").exists()
    with open(tmp_path / "docstore.json") as f:
        data = json.load(f)
    assert data["schema_version"] == 2
    assert data["dimensions"] == DIM
    # v2 records the similarity mode of the persisted vectors.
    assert data["distance"] == "cosine"


def test_save_and_load_via_path_param(tmp_path):
    embedder = StubEmbedder()
    db = TurboQuantVectorDb(embedder=embedder, path=str(tmp_path))
    db.create()
    db.insert("h", [_doc("a"), _doc("b"), _doc("c")])
    db.save()

    # Fresh store with same path should load on create().
    db2 = TurboQuantVectorDb(embedder=embedder, path=str(tmp_path))
    db2.create()
    assert len(db2._index) == 3
    # Query through the loaded store still works.
    results = db2.search("a", limit=3)
    assert len(results) == 3


@pytest.mark.parametrize("missing", ["docstore.json", "index.tvim"])
def test_create_on_a_half_present_save_raises_instead_of_starting_empty(tmp_path, missing):
    # Issue #328: create() swallowed _load_from's FileNotFoundError and
    # built a fresh empty index, so a folder holding only one of the two
    # artifacts loaded silently empty — and the next save() overwrote
    # the surviving file, destroying the data permanently.
    embedder = StubEmbedder()
    db = TurboQuantVectorDb(embedder=embedder, path=str(tmp_path))
    db.create()
    db.insert("h", [_doc("a"), _doc("b"), _doc("c")])
    db.save()
    (tmp_path / missing).unlink()
    survivor = "index.tvim" if missing == "docstore.json" else "docstore.json"
    before = (tmp_path / survivor).read_bytes()

    db2 = TurboQuantVectorDb(embedder=embedder, path=str(tmp_path))
    with pytest.raises(FileNotFoundError) as exc:
        db2.create()
    assert "missing one of" in str(exc.value)
    assert str(tmp_path) in str(exc.value)
    # The surviving artifact is untouched, so the store is recoverable.
    assert (tmp_path / survivor).read_bytes() == before


def test_create_on_an_empty_folder_still_starts_fresh(tmp_path):
    # The genuinely-fresh path — neither artifact present — must keep
    # working; only a *partial* save is an error.
    db = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db.create()
    assert len(db._index) == 0


def test_failed_save_preserves_previous_store(tmp_path):
    # Regression test for #159: a save that fails mid-serialization
    # (non-JSON-serializable meta_data) must not destroy a previously
    # persisted store at the same path, and must not leave temp files.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b")])
    db.save(str(tmp_path))
    before = {p.name: p.read_bytes() for p in tmp_path.iterdir()}

    db.insert("h2", [_doc("bad", meta_data={"bad": {1, 2, 3}})])
    with pytest.raises(TypeError):
        db.save(str(tmp_path))

    # Exact directory equality: both files byte-identical, no strays.
    after = {p.name: p.read_bytes() for p in tmp_path.iterdir()}
    assert after == before
    assert not list(tmp_path.glob("*.tmp*"))
    db2 = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db2.create()  # loads from disk
    assert len(db2._index) == 2


def test_save_requires_path():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    with pytest.raises(ValueError, match="path"):
        db.save()


def test_load_rejects_unknown_schema_version(tmp_path):
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a")])
    db.save(str(tmp_path))
    with open(tmp_path / "docstore.json") as f:
        data = json.load(f)
    data["schema_version"] = 99
    with open(tmp_path / "docstore.json", "w") as f:
        json.dump(data, f)
    with pytest.raises(ValueError, match="schema_version"):
        TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path)).create()


def test_load_rejects_dimension_mismatch(tmp_path):
    db = TurboQuantVectorDb(embedder=StubEmbedder(dim=64))
    db.create()
    db.insert("h", [_doc("a")])
    db.save(str(tmp_path))
    # New store with a different-dim embedder must refuse to load.
    with pytest.raises(ValueError, match="dimensions"):
        TurboQuantVectorDb(embedder=StubEmbedder(dim=128), path=str(tmp_path)).create()


def test_load_rejects_side_car_desynced_from_index(tmp_path):
    # A side-car that lost a handle entry while index.tvim kept the vector
    # must fail cleanly at load (issue #115), matching the other
    # integrations — not load clean and silently drop the orphaned vector
    # from search results.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b"), _doc("c")])
    db.save(str(tmp_path))

    # Clean reload works.
    TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path)).create()

    with open(tmp_path / "docstore.json") as f:
        state = json.load(f)
    state["u64_to_doc"] = state["u64_to_doc"][1:]  # drop one handle->doc
    with open(tmp_path / "docstore.json", "w") as f:
        json.dump(state, f)

    with pytest.raises(ValueError, match="out of sync"):
        TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path)).create()


def test_load_rejects_side_car_with_extra_handle(tmp_path):
    # Reverse desync direction: the side-car holds a handle the index
    # doesn't contain. Must also fail cleanly at load (issue #115).
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b")])
    db.save(str(tmp_path))

    with open(tmp_path / "docstore.json") as f:
        state = json.load(f)
    ghost = dict(state["u64_to_doc"][0][1])
    ghost["id"] = "ghost"
    state["u64_to_doc"].append([999, ghost])
    with open(tmp_path / "docstore.json", "w") as f:
        json.dump(state, f)

    with pytest.raises(ValueError, match="out of sync"):
        TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path)).create()


def test_failed_load_leaves_the_store_untouched(tmp_path):
    # agno is the only integration whose load mutates a live store in
    # place (the other three are classmethods returning a fresh object),
    # so it is the only one that can leave a caller holding a half-loaded
    # store. `check_persisted_handles` runs after the maps are rebuilt, so
    # a desynced side-car used to raise *after* `_index` and every map had
    # already been replaced: the store then reported `exists() is True`
    # and a retried `create()` returned silently as "already created",
    # handing back the corrupt half-load (#380).
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b")])
    db.save(str(tmp_path))

    with open(tmp_path / "docstore.json") as f:
        state = json.load(f)
    state["u64_to_doc"] = state["u64_to_doc"][1:]
    with open(tmp_path / "docstore.json", "w") as f:
        json.dump(state, f)

    fresh = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    with pytest.raises(ValueError, match="out of sync"):
        fresh.create()

    assert not fresh.exists(), "a failed load left the store reporting itself as created"
    assert fresh._u64_to_doc == {}, "a failed load left documents in the store"
    assert fresh._str_to_u64 == {}
    assert fresh._next_u64 == 0
    # The concrete harm: with `_index` set, the retry is a silent no-op
    # that hands back the half-load instead of re-raising.
    with pytest.raises(ValueError, match="out of sync"):
        fresh.create()


# ---- Protocol coverage ----------------------------------------------------


def test_supported_search_types():
    # Mirror LanceDb's return shape: a list of SearchType enum members
    # (not their `.value` strings). Drop-in callers iterating this list
    # would unwrap enum members, so the return type matters.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    types = db.get_supported_search_types()
    assert types == [SearchType.vector]
    assert isinstance(types[0], SearchType)


def test_upsert_available():
    assert TurboQuantVectorDb(embedder=StubEmbedder()).upsert_available() is True


# ---- Async coverage -------------------------------------------------------


def test_async_round_trip():
    import asyncio

    async def runner():
        db = TurboQuantVectorDb(embedder=StubEmbedder())
        await db.async_create()
        await db.async_insert("h", [_doc("a"), _doc("b"), _doc("c")])
        assert await db.async_exists() is True
        results = await db.async_search("a", limit=2)
        assert len(results) == 2
        await db.async_drop()
        assert await db.async_exists() is False

    asyncio.run(runner())


# ---- End-to-end smoke test: framework wiring -----------------------------


def test_knowledge_search_routes_through_vector_db():
    # Smoke test: build an Agno Knowledge with our vector_db and call
    # Knowledge.search() — the framework's top-level retrieval API.
    # Exercises the wiring between Knowledge and VectorDb.search.
    from agno.knowledge import Knowledge

    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    # Seed the underlying vector_db directly — Knowledge.add_content's
    # real path goes through readers, which we don't need to exercise
    # here. The smoke test target is the search-routing surface.
    db.insert(
        "seed",
        [
            _doc("alpha", doc_id="d1", meta_data={"category": "a"}),
            _doc("beta",  doc_id="d2", meta_data={"category": "b"}),
            _doc("gamma", doc_id="d3", meta_data={"category": "a"}),
        ],
    )

    knowledge = Knowledge(vector_db=db)
    results = knowledge.search("alpha", max_results=3)
    assert len(results) == 3
    assert all(isinstance(r, Document) for r in results)


def test_knowledge_search_with_filter_routes_through_kernel_allowlist():
    # Verify the filter kwarg reaches our search() through Knowledge's
    # wrapper, and that the kernel-level allowlist path is used (not
    # post-filtering).
    from agno.knowledge import Knowledge

    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert(
        "seed",
        [
            _doc(f"text-{i}", doc_id=f"d-{i}",
                 meta_data={"tag": "needle" if i in (7, 23, 41) else "hay"})
            for i in range(50)
        ],
    )

    knowledge = Knowledge(vector_db=db)
    results = knowledge.search(
        "text-0",
        max_results=3,
        filters={"tag": "needle"},
    )
    # Selective filter: 3 of 50 match; max_results=3 must return all 3.
    # Post-filter+over-fetch would have returned <3 results.
    assert len(results) == 3
    assert all(r.meta_data["tag"] == "needle" for r in results)


# ---- Reranker integration -------------------------------------------------


def test_reranker_called_on_search_results():
    # Verify the constructor's `reranker` is actually invoked on the
    # search() result list and that its return value replaces the
    # unranked order.
    ReverseReranker.calls = 0
    reranker = ReverseReranker()
    db = TurboQuantVectorDb(embedder=StubEmbedder(), reranker=reranker)
    db.create()
    db.insert("h", [_doc("a"), _doc("b"), _doc("c")])
    results = db.search("a", limit=3)
    assert ReverseReranker.calls == 1
    # ReverseReranker reverses, so the natural top-result (the self-match
    # 'a') ends up last after rerank.
    assert results[-1].content == "a"


def test_reranker_called_on_async_search_results():
    import asyncio

    async def runner():
        ReverseReranker.calls = 0
        reranker = ReverseReranker()
        db = TurboQuantVectorDb(embedder=StubEmbedder(), reranker=reranker)
        await db.async_create()
        await db.async_insert("h", [_doc("a"), _doc("b"), _doc("c")])
        results = await db.async_search("a", limit=3)
        assert ReverseReranker.calls == 1
        assert results[-1].content == "a"

    asyncio.run(runner())


def test_reranker_not_called_on_empty_results():
    # Defensive: an empty results list shouldn't go to the reranker —
    # nothing to rank. Avoids unnecessary work.
    ReverseReranker.calls = 0
    reranker = ReverseReranker()
    db = TurboQuantVectorDb(embedder=StubEmbedder(), reranker=reranker)
    db.create()
    # No documents inserted -> empty search results.
    results = db.search("anything", limit=5)
    assert results == []
    assert ReverseReranker.calls == 0


# ---- insert(filters=) merges into meta_data -------------------------------


def test_insert_filters_kwarg_merges_into_doc_metadata():
    # The `filters` kwarg on insert should merge into each document's
    # meta_data — matches LanceDb's contract where these become part of
    # the doc's stored metadata and are searchable later.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    docs = [
        _doc("a", doc_id="d1", meta_data={"existing": 1}),
        _doc("b", doc_id="d2", meta_data={"existing": 2}),
    ]
    db.insert("h", docs, filters={"tenant": "acme", "tier": "pro"})
    # Length first: this loop passes vacuously if insert stores nothing.
    assert len(db._u64_to_doc) == 2
    for data in db._u64_to_doc.values():
        # Original meta_data preserved...
        assert "existing" in data["meta_data"]
        # ...and the filter kwargs merged in.
        assert data["meta_data"]["tenant"] == "acme"
        assert data["meta_data"]["tier"] == "pro"


def test_insert_filters_kwarg_is_searchable_after_insert():
    # The merged filter values should be visible to subsequent
    # search(..., filters={...}) calls — they're real metadata now.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h-a", [_doc("alpha")], filters={"tenant": "acme"})
    db.insert("h-b", [_doc("beta")],  filters={"tenant": "globex"})
    results = db.search("alpha", limit=5, filters={"tenant": "acme"})
    assert len(results) == 1
    assert results[0].content == "alpha"


# ---- Async-only coverage --------------------------------------------------


def test_async_name_exists():
    import asyncio

    async def runner():
        db = TurboQuantVectorDb(embedder=StubEmbedder())
        await db.async_create()
        await db.async_insert("h", [_doc("a", name="foo.pdf")])
        assert await db.async_name_exists("foo.pdf") is True
        assert await db.async_name_exists("missing.pdf") is False

    asyncio.run(runner())


def test_async_get_count():
    import asyncio

    async def runner():
        db = TurboQuantVectorDb(embedder=StubEmbedder())
        assert await db.async_get_count() == 0  # before create
        await db.async_create()
        await db.async_insert("h", [_doc("a"), _doc("b")])
        assert await db.async_get_count() == 2

    asyncio.run(runner())


def test_async_upsert_replaces_by_content_hash():
    # Same contract as sync upsert: replace everything under the
    # given content_hash. Exercises the async code path explicitly.
    import asyncio

    async def runner():
        db = TurboQuantVectorDb(embedder=StubEmbedder())
        await db.async_create()
        await db.async_insert("hv1", [_doc("a"), _doc("b"), _doc("c")])
        assert db.get_count() == 3
        await db.async_upsert("hv1", [_doc("z")])
        assert db.get_count() == 1

    asyncio.run(runner())


def test_async_upsert_concurrent_same_content_hash_is_last_writer_wins():
    # Regression test for issue #146: async_upsert captured old_handles
    # BEFORE the awaited embed, so concurrent upserts of the same
    # content_hash all snapshotted the same pre-insert handle set and no
    # task removed a sibling's rows — stale generations accumulated.
    # Deterministic: the embedder suspends both tasks at an asyncio.Event
    # gate, guaranteeing both are in flight before either inserts.
    import asyncio

    class GatedEmbedder(StubEmbedder):
        enable_batch = True
        gate: asyncio.Event

        def get_embeddings_batch_and_usage(self, texts):
            return [self._embed(t) for t in texts], [None] * len(texts)

        async def async_get_embeddings_batch_and_usage(self, texts):
            # Controlled suspension: park here until the test releases
            # the gate, so both upsert tasks interleave deterministically.
            await self.gate.wait()
            return [self._embed(t) for t in texts], [None] * len(texts)

    embedder = GatedEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()

    async def runner():
        embedder.gate = asyncio.Event()
        # Seed an existing generation so stale-generation removal is
        # exercised too, not just sibling-batch removal.
        db.upsert("ch", [_doc("gen 0", doc_id="d")])
        assert db.get_count() == 1
        t1 = asyncio.create_task(
            db.async_upsert("ch", [Document(id="d", content="gen A")])
        )
        t2 = asyncio.create_task(
            db.async_upsert("ch", [Document(id="d", content="gen B")])
        )
        # Let both tasks run up to the gate (both suspended mid-embed).
        await asyncio.sleep(0)
        embedder.gate.set()
        await asyncio.gather(t1, t2)

    asyncio.run(runner())
    # Replace-all contract: exactly one generation survives, and it's the
    # last writer's (t2 resumes after t1, matching sync semantics).
    assert db.get_count() == 1
    [survivor] = db._u64_to_doc.values()
    assert survivor["content"] == "gen B"


# ---- Batch embedder paths -------------------------------------------------


def test_insert_uses_sync_batch_embedder_path():
    # When embedder.enable_batch is True AND it exposes
    # get_embeddings_batch_and_usage, insert() should route through that
    # batch method instead of per-document embed() calls.
    emb = BatchEmbedder()
    db = TurboQuantVectorDb(embedder=emb)
    db.create()
    # Docs without embeddings → must be embedded by the integration.
    docs = [
        _doc("a", doc_id="d1", pre_embed=False),
        _doc("b", doc_id="d2", pre_embed=False),
        _doc("c", doc_id="d3", pre_embed=False),
    ]
    db.insert("h", docs)
    assert emb.sync_batch_calls == 1
    assert db.get_count() == 3


def test_async_insert_uses_async_batch_embedder_path():
    import asyncio

    async def runner():
        emb = BatchEmbedder()
        db = TurboQuantVectorDb(embedder=emb)
        await db.async_create()
        docs = [
            _doc("a", doc_id="d1", pre_embed=False),
            _doc("b", doc_id="d2", pre_embed=False),
        ]
        await db.async_insert("h", docs)
        assert emb.async_batch_calls == 1
        assert db.get_count() == 2

    asyncio.run(runner())


# ---- Defensive None-guard paths ------------------------------------------


def test_save_before_create_raises():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    with pytest.raises(RuntimeError, match="no index to save"):
        db.save("/tmp/nonexistent-turbovec-store")


def test_update_metadata_before_create_is_noop():
    # Defensive: calling update_metadata before create() shouldn't
    # raise; it just has no documents to touch.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.update_metadata("any-content-id", {"key": "value"})  # no assertion: must not raise


def test_update_metadata_unknown_content_id_is_noop():
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a", content_id="cid-known", meta_data={"k": 1})])
    db.update_metadata("cid-not-in-store", {"k": 2})
    # Nothing changed on the known doc.
    docs = list(db._u64_to_doc.values())
    assert docs[0]["meta_data"] == {"k": 1}


def test_none_content_id_does_not_match_docs_without_content_id():
    # Secondary part of issue #169: docs stored without a content_id keep
    # it as None, so `.get("content_id") == content_id` made
    # delete_by_content_id(None) / update_metadata(None, ...) match every
    # such doc. None is off-contract (param typed str) — treat it as a
    # no-op instead of a whole-collection match.
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    db.create()
    db.insert("h", [_doc("a"), _doc("b")])  # no content_id on either
    assert db.delete_by_content_id(None) is False
    assert db.get_count() == 2
    db.update_metadata(None, {"tag": "oops"})
    assert all(d["meta_data"] == {} for d in db._u64_to_doc.values())


# ---- Tier-2 field-completeness tests. Each pins behaviour around
# Document fields that are populated, omitted, or diverged from LanceDb.
# Without these, a refactor could silently change the contract. ----

def test_search_results_content_origin_divergence_from_lancedb():
    # `Document.content_origin` is an agno field set by some Reader
    # pipelines. LanceDb drops it on insert (stores `payload` as opaque
    # JSON of {id, name, meta_data, content_id, usage} only); turbovec
    # mirrors that. Pin the divergence so a future caller doesn't quietly
    # start relying on the field surviving — and so a future preservation
    # change (turbovec preserving it where LanceDb doesn't) is a
    # deliberate decision.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    doc = Document(
        id="d-1",
        content="hello",
        embedding=embedder._embed("hello"),
        content_origin="pdf",
    )
    db.insert("h", [doc])
    [result] = db.search("hello", limit=1)
    # Matches LanceDb behaviour: content_origin is not preserved.
    assert result.content_origin is None


def test_search_results_size_divergence_from_lancedb():
    # Same divergence pin for `Document.size`.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    doc = Document(
        id="d-1",
        content="hello",
        embedding=embedder._embed("hello"),
        size=42,
    )
    db.insert("h", [doc])
    [result] = db.search("hello", limit=1)
    assert result.size is None


def test_search_results_embedding_is_none_divergence_from_lancedb():
    # LanceDb's `_build_search_results` sets `embedding=item["vector"]`
    # so callers can read the original vector off a returned hit.
    # turbovec quantizes vectors to 2-4 bits per dim and discards the
    # full-precision form — the original vector is unrecoverable, so
    # we return `embedding=None`. Pin this so a caller who depends on
    # `result.embedding` after retrieval (e.g. for rerank-by-similarity)
    # gets a clear contract from the test suite, not a runtime surprise.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [_doc("a", doc_id="d-1")])
    [result] = db.search("a", limit=1)
    assert result.embedding is None


def test_reranker_output_documents_carry_reranking_score():
    # When the reranker sets `reranking_score`, it must survive the
    # post-rerank result list. Existing reranker tests only check the
    # order; a refactor that re-threads `embedder` could drop other
    # fields the reranker mutated.
    from agno.knowledge.reranker.base import Reranker as _AgnoReranker

    class ScoringReranker(_AgnoReranker):
        def rerank(self, query: str, documents):
            for i, d in enumerate(documents):
                d.reranking_score = float(len(documents) - i)
            return documents

    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder, reranker=ScoringReranker())
    db.create()
    db.insert("h", [_doc(f"doc-{i}") for i in range(3)])

    results = db.search("doc-0", limit=3)
    assert all(r.reranking_score is not None for r in results)
    assert all(isinstance(r.reranking_score, float) for r in results)


def test_delete_by_metadata_returns_false_when_no_match():
    # `delete_by_*` methods return bool — True when at least one doc
    # matched (and was deleted), False otherwise. Other delete tests
    # cover the True branch; this pins the False branch so a regression
    # always returning True can't silently mask "I expected to delete
    # something and nothing matched" upstream.
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder)
    db.create()
    db.insert("h", [_doc("a", meta_data={"tag": "x"})])
    assert db.delete_by_metadata({"tag": "no-such-value"}) is False
    # Original doc still present.
    assert db.get_count() == 1


# ---- Security/data-integrity regression (issue #104) ----------------------


def test_duplicate_doc_id_keeps_both_vectors_no_orphan():
    # agno's reference store (LanceDb) is append-only: two docs with the same
    # explicit id (hence same derived doc_id) are BOTH stored. Previously the
    # one-to-one _str_to_u64 map orphaned the first vector — counted and
    # searchable but undeletable. Both must now be reachable and deletable.
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("h", [_doc("alpha", doc_id="dup"), _doc("beta", doc_id="dup")])

    assert db.get_count() == 2
    [doc_id] = list(db._str_to_u64)            # both collapse to one derived id
    assert len(db._str_to_u64[doc_id]) == 2    # ...mapping to both handles
    assert len(db._u64_to_doc) == 2

    # Deleting that id removes BOTH vectors, leaving no orphan behind.
    assert db.delete_by_id(doc_id)
    assert db.get_count() == 0
    assert db._str_to_u64 == {}
    assert db._u64_to_doc == {}


def test_duplicate_doc_id_survives_persistence_roundtrip(tmp_path):
    embedder = StubEmbedder(DIM)
    db = TurboQuantVectorDb(embedder=embedder, path=str(tmp_path))
    db.create()
    db.insert("h", [_doc("alpha", doc_id="dup"), _doc("beta", doc_id="dup")])
    db.save()

    # Reload must rebuild the one-to-many id map, not drop a handle.
    db2 = TurboQuantVectorDb(embedder=embedder, path=str(tmp_path))
    db2.create()
    assert db2.get_count() == 2
    [doc_id] = list(db2._str_to_u64)
    assert len(db2._str_to_u64[doc_id]) == 2


def _doc_same_content(name=None, content_id=None, meta_data=None):
    # All share identical content + no explicit id -> identical derived doc_id,
    # differing only by name/content_id/metadata.
    return _doc("identical", name=name, content_id=content_id, meta_data=meta_data)


def test_delete_by_name_only_removes_matching_name_on_doc_id_collision():
    # name is not part of the derived doc_id, so two differently-named docs
    # with identical content collide. delete_by_name must remove only the
    # named doc, not its id-twin, and must not leave a stale name entry.
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("h", [_doc_same_content(name="A"), _doc_same_content(name="B")])
    assert db.get_count() == 2

    assert db.delete_by_name("A") is True
    assert db.get_count() == 1
    assert db.name_exists("A") is False  # no stale entry
    assert db.name_exists("B") is True


def test_delete_by_content_id_only_removes_matching_on_doc_id_collision():
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("h", [_doc_same_content(content_id="c1"), _doc_same_content(content_id="c2")])
    assert db.get_count() == 2

    assert db.delete_by_content_id("c1") is True
    assert db.get_count() == 1  # c2 survives


def test_delete_by_metadata_only_removes_matching_on_doc_id_collision():
    db = TurboQuantVectorDb(embedder=StubEmbedder(DIM))
    db.create()
    db.insert("h", [_doc_same_content(meta_data={"k": "x"}), _doc_same_content(meta_data={"k": "y"})])
    assert db.get_count() == 2

    assert db.delete_by_metadata({"k": "x"}) is True
    assert db.get_count() == 1  # the {"k": "y"} doc survives


# ---- Embedder-output validation (issue #154) ------------------------------


class NoneBatchEmbedder(StubEmbedder):
    """Misbehaving batch embedder: the batch call returns (None, None)
    instead of the embeddings/usages lists."""

    enable_batch = True

    def get_embeddings_batch_and_usage(self, texts):
        return None, None

    async def async_get_embeddings_batch_and_usage(self, texts):
        return None, None


def test_insert_batch_embedder_returning_none_raises_failed_to_embed():
    # On main this died with `TypeError: object of type 'NoneType' has no
    # len()` inside _embed_missing. It must fall through to the same
    # "failed to embed" error the missing-embedding check already raises.
    db = TurboQuantVectorDb(embedder=NoneBatchEmbedder(DIM))
    db.create()
    with pytest.raises(ValueError, match="failed to embed 2 document"):
        db.insert("h", [Document(content="a"), Document(content="b")])
    assert db.get_count() == 0


def test_async_insert_batch_embedder_returning_none_raises_failed_to_embed():
    import asyncio

    db = TurboQuantVectorDb(embedder=NoneBatchEmbedder(DIM))
    db.create()
    with pytest.raises(ValueError, match="failed to embed 2 document"):
        asyncio.run(
            db.async_insert("h", [Document(content="a"), Document(content="b")])
        )
    assert db.get_count() == 0


def test_insert_batch_embedder_empty_vectors_raises_failed_to_embed():
    # Pins the (N, 0) mode: a batch of empty per-document embeddings is
    # caught by the missing-embedding check (empty list == not embedded),
    # never reaching the index kernel.
    class EmptyBatchEmbedder(StubEmbedder):
        enable_batch = True

        def get_embeddings_batch_and_usage(self, texts):
            return [[] for _ in texts], [None for _ in texts]

    db = TurboQuantVectorDb(embedder=EmptyBatchEmbedder(DIM))
    db.create()
    with pytest.raises(ValueError, match="failed to embed 2 document"):
        db.insert("h", [Document(content="a"), Document(content="b")])
    assert db.get_count() == 0


def test_failed_insert_preserves_a_colliding_pre_existing_document(tmp_path):
    # Issue #321: the maps-first write overwrites `_u64_to_doc[h]` when a
    # corrupt watermark reissues a live handle. The unwind used to pop
    # that slot unconditionally, destroying the VICTIM's payload while
    # unlinking the NEW doc's id/name — violating the issue-#89 guarantee
    # that a failed add never destroys existing data.
    db = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db.create()
    db.insert("h1", [_doc("alpha", doc_id="A", name="A")])

    before_docs = _copy.deepcopy(db._u64_to_doc)
    before_ids = _copy.deepcopy(db._str_to_u64)
    before_names = _copy.deepcopy(db._name_to_ids)
    before_hashes = set(db._content_hashes)

    # Rewind the watermark so the next handle collides with A's.
    db._next_u64 = 0
    victim_doc = _doc("beta", doc_id="B", name="B")
    victim_doc.embedding = [float("nan")] * DIM
    with pytest.raises(Exception):
        db.insert("h2", [victim_doc])

    # A is intact in every map, and the failed doc left nothing behind.
    assert db._u64_to_doc == before_docs
    assert db._str_to_u64 == before_ids
    assert db._name_to_ids == before_names
    assert db._content_hashes == before_hashes
    assert db.get_count() == 1
    assert len(db._index) == 1


def test_failed_insert_without_collision_still_unwinds_cleanly(tmp_path):
    # The non-colliding path (the common case) must be unaffected by the
    # #321 restore.
    db = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db.create()
    db.insert("h1", [_doc("alpha", doc_id="A", name="A")])
    bad = _doc("beta", doc_id="B", name="B")
    bad.embedding = [float("nan")] * DIM
    with pytest.raises(Exception):
        db.insert("h2", [bad])
    assert db.get_count() == 1
    assert "h2" not in db._content_hashes
    assert "B" not in db._name_to_ids
    assert len(db._u64_to_doc) == 1


def test_load_rejects_a_rewound_next_u64_watermark(tmp_path):
    # Issue #321 part 2: `check_persisted_handles` validated duplicates,
    # count parity and membership, but never the watermark — so a stale
    # or hand-edited side-car loaded cleanly and then bricked every
    # subsequent write with "id N already present in index".
    db = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db.create()
    db.insert("h1", [_doc("alpha", doc_id="A", name="A")])
    db.save()

    store_file = tmp_path / "docstore.json"
    state = json.loads(store_file.read_text())
    assert state["next_u64"] >= 1
    state["next_u64"] = 0
    store_file.write_text(json.dumps(state))

    db2 = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    with pytest.raises(ValueError, match="next_u64"):
        db2.create()


def test_load_accepts_a_watermark_above_the_largest_handle(tmp_path):
    # A watermark ahead of the handles is fine — it only skips ids.
    db = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db.create()
    db.insert("h1", [_doc("alpha", doc_id="A", name="A")])
    db.save()

    store_file = tmp_path / "docstore.json"
    state = json.loads(store_file.read_text())
    state["next_u64"] = 10_000
    store_file.write_text(json.dumps(state))

    db2 = TurboQuantVectorDb(embedder=StubEmbedder(), path=str(tmp_path))
    db2.create()
    assert db2.get_count() == 1


# ---------------------------------------------------------------------------
# Contract divergences from agno's own semantics (#502, #503, #496)
# ---------------------------------------------------------------------------


def test_search_type_rejects_unsupported_values_at_runtime_not_just_init():
    """agno's `Knowledge.search` assigns `vector_db.search_type` directly
    before searching, without consulting `get_supported_search_types()`.
    As a plain attribute that mutation succeeded silently and the store
    served vector-only results for a hybrid request (#502)."""
    db = TurboQuantVectorDb(embedder=StubEmbedder())
    assert db.search_type == SearchType.vector

    for bad in (SearchType.hybrid, SearchType.keyword):
        with pytest.raises(ValueError, match="only supports search_type"):
            db.search_type = bad
        # And the attribute must not have been left misreporting.
        assert db.search_type == SearchType.vector

    # The supported value still assigns.
    db.search_type = SearchType.vector
    assert db.search_type == SearchType.vector


def test_cosine_similarity_threshold_uses_raw_cosine():
    """agno defines the cosine score as the raw cosine — `normalize_cosine`
    is `1 - distance` and pgvector enforces `cos >= threshold`. Mapping
    through `(cos + 1) / 2` admitted everything down to `2t - 1` (#503)."""
    cos = TurboQuantVectorDb(embedder=StubEmbedder(), distance=Distance.cosine)
    # Raw cosine passes straight through, clamped to [0, 1].
    assert cos._scaled_similarity(0.90) == pytest.approx(0.90)
    assert cos._scaled_similarity(0.80) == pytest.approx(0.80)
    assert cos._scaled_similarity(-0.5) == 0.0
    assert cos._scaled_similarity(1.2) == 1.0
    # The old mapping would have scored cos=0.80 as 0.90 and let it past
    # a 0.9 threshold.
    assert cos._scaled_similarity(0.80) < 0.9

    ip = TurboQuantVectorDb(
        embedder=StubEmbedder(), distance=Distance.max_inner_product
    )
    # Inner product keeps agno's (ip + 1) / 2.
    assert ip._scaled_similarity(0.80) == pytest.approx(0.90)
    assert ip._scaled_similarity(0.0) == pytest.approx(0.5)


def test_async_insert_does_not_embed_on_the_event_loop():
    """With the default embedder (`enable_batch=False`) the async path used
    to call the blocking sync embed on the loop thread, one document at a
    time — stalling every other coroutine for the whole embed (#496)."""
    import asyncio
    import time

    class SlowEmbedder(StubEmbedder):
        enable_batch = False

        def __init__(self, dim: int = DIM) -> None:
            super().__init__(dim)
            self.sync_calls = 0
            self.async_calls = 0

        def get_embedding(self, text: str) -> list[float]:
            self.sync_calls += 1
            time.sleep(0.02)
            return self._embed(text)

        def get_embedding_and_usage(self, text: str):
            return self.get_embedding(text), None

        async def async_get_embedding(self, text: str) -> list[float]:
            self.async_calls += 1
            await asyncio.sleep(0.02)
            return self._embed(text)

        async def async_get_embedding_and_usage(self, text: str):
            return await self.async_get_embedding(text), None

    async def run():
        emb = SlowEmbedder()
        db = TurboQuantVectorDb(embedder=emb)
        db.create()
        docs = [Document(content=f"doc-{i}") for i in range(10)]

        gaps = []
        stop = False

        async def heartbeat():
            last = time.perf_counter()
            while not stop:
                await asyncio.sleep(0.005)
                now = time.perf_counter()
                gaps.append(now - last)
                last = now

        hb = asyncio.create_task(heartbeat())
        await db.async_insert("h", docs)
        hb.cancel()
        try:
            await hb
        except asyncio.CancelledError:
            pass
        return emb, max(gaps) if gaps else 0.0

    emb, worst_gap = asyncio.run(run())
    # 10 documents x 20 ms serial on the loop thread would be ~0.2 s; the
    # loop must keep ticking far faster than that.
    assert worst_gap < 0.1, f"event loop stalled for {worst_gap:.3f}s during async_insert"
    assert emb.async_calls == 10, f"expected the async embed path, got {emb.async_calls}"
    assert emb.sync_calls == 0, f"blocking embed ran on the loop ({emb.sync_calls} calls)"


def test_async_insert_still_works_with_a_sync_only_embedder():
    """The async path must not route a sync-only embedder into
    `Document.async_embed`, which delegates to the base
    `Embedder.async_get_embedding_and_usage` and raises
    NotImplementedError. The capability test has to interrogate the
    embedder, not the document — every agno Document defines
    `async_embed`."""
    import asyncio

    class SyncOnlyEmbedder:
        enable_batch = False

        def __init__(self, dim: int = DIM) -> None:
            self.dimensions = dim
            self.calls = 0

        def _embed(self, text: str) -> list[float]:
            rng = np.random.default_rng(abs(hash(text)) % (2**32))
            v = rng.standard_normal(self.dimensions).astype(np.float32)
            v /= np.linalg.norm(v) + 1e-9
            return v.tolist()

        def get_embedding(self, text: str) -> list[float]:
            self.calls += 1
            return self._embed(text)

        def get_embedding_and_usage(self, text: str):
            return self.get_embedding(text), None

    async def run():
        emb = SyncOnlyEmbedder()
        db = TurboQuantVectorDb(embedder=emb)
        db.create()
        await db.async_insert("h", [Document(content=f"d{i}") for i in range(4)])
        return emb, db

    emb, db = asyncio.run(run())
    assert emb.calls == 4, f"sync embedder should have been used, got {emb.calls}"
    assert db.get_count() == 4


class CountingEmbedder(StubEmbedder):
    """StubEmbedder that records how many times it was asked to embed.

    A write into a store that never had create() called is doomed, so the
    embedder — which may be a paid API call or GPU work — must not run
    first (#473).
    """

    def __init__(self, dim: int = DIM) -> None:
        super().__init__(dim)
        self.calls = 0

    def get_embedding(self, text: str) -> list[float]:
        self.calls += 1
        return super().get_embedding(text)

    async def async_get_embedding(self, text: str) -> list[float]:
        self.calls += 1
        return await super().async_get_embedding(text)

    # Agno's Document.embed goes through the *_and_usage surface, so the
    # counter has to cover it too or an unfixed build never reaches the
    # assertion.
    def get_embedding_and_usage(self, text: str):
        self.calls += 1
        return self._embed(text), {"tokens": 1}

    async def async_get_embedding_and_usage(self, text: str):
        self.calls += 1
        return self._embed(text), {"tokens": 1}


def test_async_insert_before_create_does_not_embed():
    import asyncio

    emb = CountingEmbedder()
    db = TurboQuantVectorDb(embedder=emb)
    with pytest.raises(RuntimeError, match="not initialized"):
        asyncio.run(db.async_insert("h", [_doc("a", pre_embed=False)]))
    assert emb.calls == 0, "embedded a document for a write that could not succeed"


def test_upsert_before_create_does_not_embed():
    emb = CountingEmbedder()
    db = TurboQuantVectorDb(embedder=emb)
    with pytest.raises(RuntimeError, match="not initialized"):
        db.upsert("h", [_doc("a", pre_embed=False)])
    assert emb.calls == 0, "embedded a document for a write that could not succeed"


def test_async_upsert_before_create_does_not_embed():
    import asyncio

    emb = CountingEmbedder()
    db = TurboQuantVectorDb(embedder=emb)
    with pytest.raises(RuntimeError, match="not initialized"):
        asyncio.run(db.async_upsert("h", [_doc("a", pre_embed=False)]))
    assert emb.calls == 0, "embedded a document for a write that could not succeed"


def test_empty_writes_before_create_still_do_nothing():
    """The guard must not turn a no-op into an error."""
    import asyncio

    db = TurboQuantVectorDb(embedder=CountingEmbedder())
    db.insert("h", [])
    asyncio.run(db.async_insert("h", []))
